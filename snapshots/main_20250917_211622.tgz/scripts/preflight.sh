#!/usr/bin/env bash
set -e

echo "Pre-flight checks"

# --- pick env file ---
ENV_FILE="${ENV_PATH:-.env.live}"

if [ ! -f "$ENV_FILE" ]; then
  echo "✖ Env file $ENV_FILE not found"
  exit 1
fi

# --- python present? ---
if ! command -v python3 >/dev/null 2>&1; then
  echo "✖ Python3 not found"
  exit 1
fi
echo "✔ Python present"

# --- try import sanity ---
python3 - <<'PY'
from dotenv import load_dotenv; import os
env_file = os.getenv("ENV_PATH", ".env.live")
load_dotenv(env_file)
import importlib
try:
    importlib.import_module("bot.run")
    print("ok")
    print("✔ Import sanity ok")
except Exception as e:
    print("✖ Import failed:", e)
    raise
PY

# --- grid params check (example stub) ---
: "${GRID_LOWER:=}"
: "${GRID_UPPER:=}"
: "${GRID_STEP:=}"
: "${LOT:=}"
if [ -z "$GRID_LOWER$GRID_UPPER$GRID_STEP$LOT" ]; then
  echo "▲ GRID_LOWER/GRID_UPPER/GRID_STEP/LOT not fully set (bot will use defaults if coded)"
else
  echo "✔ Grid params look sensible"
fi

# --- echo key flags ---
EXECUTE_ORDERS=$(grep -E '^EXECUTE_ORDERS=' "$ENV_FILE" | tail -n1 | cut -d= -f2-)
DELTA_DRY_ORDERS=$(grep -E '^DELTA_DRY_ORDERS=' "$ENV_FILE" | tail -n1 | cut -d= -f2-)
I_UNDERSTAND_LIVE=$(grep -E '^I_UNDERSTAND_LIVE=' "$ENV_FILE" | tail -n1 | cut -d= -f2-)

echo "EXECUTE_ORDERS=$EXECUTE_ORDERS  DELTA_DRY_ORDERS=$DELTA_DRY_ORDERS  I_UNDERSTAND_LIVE=$I_UNDERSTAND_LIVE"

if [ "$EXECUTE_ORDERS" = "true" ] && [ "$I_UNDERSTAND_LIVE" = "YES" ]; then
  echo "✔ Live-like mode (dangerous if not intended)"
else
  echo "✔ Not in live-like mode (safe)"
fi

echo
echo "✔ Pre-flight complete"
#!/usr/bin/env bash
set -euo pipefail
GRN=$'\033[32m'; CYA=$'\033[36m'; DIM=$'\033[2m'; CLR=$'\033[0m'
echo "${CYA}Running Export/PnL…${CLR}"
python scripts/misc_debug/export_pnl.py
echo "${GRN}Export complete.${CLR} ${DIM}(CSV in bot/audit, optional XLSX if openpyxl installed)${CLR}"

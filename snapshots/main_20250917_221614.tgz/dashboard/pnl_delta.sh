#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

ENV_PATH="${ENV_PATH:-.env}"
export ENV_PATH

DAYS="${1:-1}"
OUTDIR="${2:-reports}"

python3 -m bot.reports.pnl_delta --days "$DAYS" --outdir "$OUTDIR"

#!/usr/bin/env python3
import os, sys, time, hmac, json, csv, hashlib, requests, argparse
from datetime import datetime, timezone
from typing import Dict, List, Optional, Any

try:
    from dotenv import load_dotenv
    env_path = os.getenv("ENV_PATH", ".env")
    if os.path.exists(env_path):
        load_dotenv(env_path)
except Exception:
    pass

def env_str(name: str, default: str) -> str:
    v = os.getenv(name, default)
    return v if v is not None else default

def utcnow_us() -> int:
    return int(time.time() * 1_000_000)

def to_dt(us: int) -> str:
    try:
        return datetime.fromtimestamp(int(us)/1_000_000, tz=timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(us)

class DeltaAPI:
    def __init__(self, api_key: str, api_secret: str, base_url: str):
        self.key = api_key
        self.secret = api_secret.encode("utf-8")
        self.base = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "gridbot-pnl-reporter","Content-Type": "application/json"})

    def _sign(self, method: str, timestamp: str, path: str, query: str, payload: str) -> str:
        msg = (method + timestamp + path + query + payload).encode("utf-8")
        return hmac.new(self.secret, msg, hashlib.sha256).hexdigest()

    def _request(self, method: str, path: str, params: Optional[Dict[str, Any]] = None, payload: Optional[Dict[str, Any]] = None) -> Dict:
        url = f"{self.base}{path}"
        qs = ""
        if method.upper() == "GET":
            if params:
                qs = "?" + "&".join(f"{k}={v}" for k, v in params.items())
            timestamp = str(int(time.time()))
            sig = self._sign("GET", timestamp, path, qs, "")
            headers = {"api-key": self.key, "timestamp": timestamp, "signature": sig}
            r = self.session.get(url, params=params, headers=headers, timeout=(5, 30))
        else:
            data = json.dumps(payload or {})
            timestamp = str(int(time.time()))
            sig = self._sign("POST", timestamp, path, "", data)
            headers = {"api-key": self.key, "timestamp": timestamp, "signature": sig}
            r = self.session.post(url, data=data, headers=headers, timeout=(5, 30))
        r.raise_for_status()
        return r.json()

    def positions(self) -> List[Dict]:
        res = self._request("GET", "/v2/positions/margined")
        return res.get("result", []) if res.get("success") else []

    def fills(self, start_us: int, end_us: int, page_size: int = 100) -> List[Dict]:
        all_fills: List[Dict] = []
        after = None
        while True:
            params = {"start_time": start_us, "end_time": end_us, "page_size": page_size}
            if after: params["after"] = after
            res = self._request("GET", "/v2/fills", params)
            if not res.get("success"): break
            batch = res.get("result", []) or []
            if not batch: break
            all_fills.extend(batch)
            meta = res.get("meta", {}) or {}
            after = meta.get("after")
            if not after: break
            time.sleep(0.1)
        return all_fills

    def balances(self) -> List[Dict]:
        res = self._request("GET", "/v2/wallet/balances")
        return res.get("result", []) if res.get("success") else []

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def csv_write(path: str, rows: List[Dict], fieldnames: List[str]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            w.writerow(r)

def open_positions_report(positions: List[Dict], outdir: str) -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    fp = os.path.join(outdir, f"open_positions_{ts}.csv")
    rows: List[Dict] = []
    total_realized = total_unrealized = total_commission_blocked = total_funding_realized = 0.0
    for p in positions:
        realized = float(p.get("realized_pnl", 0) or 0)
        unrealized = float(p.get("unrealized_pnl", 0) or 0)
        commission_blocked = float(p.get("commission", p.get("commission_blocked", 0)) or 0)
        funding_real = float(p.get("realized_funding", 0) or 0)
        rows.append({
            "Product_Symbol": p.get("product_symbol"),
            "Product_ID": p.get("product_id"),
            "Position_Size": p.get("size"),
            "Entry_Price": p.get("entry_price"),
            "Mark_Price": p.get("mark_price", ""),
            "Unrealized_PnL": unrealized,
            "Realized_PnL": realized,
            "Realized_Funding": funding_real,
            "Commission_Blocked": commission_blocked,
            "Margin": p.get("margin"),
            "Liq_Price": p.get("liquidation_price"),
            "Bankruptcy_Price": p.get("bankruptcy_price"),
            "ADL_Level": p.get("adl_level"),
            "Created_At": p.get("created_at"),
            "Updated_At": p.get("updated_at"),
        })
        total_realized += realized
        total_unrealized += unrealized
        total_commission_blocked += commission_blocked
        total_funding_realized += funding_real
    rows.append({
        "Product_Symbol": "--- SUMMARY ---","Product_ID":"","Position_Size":"","Entry_Price":"","Mark_Price":"",
        "Unrealized_PnL": f"{total_unrealized:.8f}","Realized_PnL": f"{total_realized:.8f}",
        "Realized_Funding": f"{total_funding_realized:.8f}","Commission_Blocked": f"{total_commission_blocked:.8f}",
        "Margin":"","Liq_Price":"","Bankruptcy_Price":"","ADL_Level":"","Created_At":"","Updated_At":"",
    })
    csv_write(fp, rows, list(rows[0].keys()) if rows else
        ["Product_Symbol","Product_ID","Position_Size","Entry_Price","Mark_Price","Unrealized_PnL","Realized_PnL","Realized_Funding","Commission_Blocked","Margin","Liq_Price","Bankruptcy_Price","ADL_Level","Created_At","Updated_At"])
    return fp

def trade_history_report(fills: List[Dict], outdir: str) -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    fp = os.path.join(outdir, f"trade_history_{ts}.csv")
    rows: List[Dict] = []
    total_commission = total_buy_value = total_sell_value = 0.0
    for f in fills:
        size = float(f.get("size", 0) or 0)
        price = float(f.get("price", 0) or 0)
        comm = float(f.get("commission", 0) or 0)
        total_value = size * price
        total_commission += abs(comm)
        if f.get("side") == "buy": total_buy_value += total_value
        else: total_sell_value += total_value
        created = f.get("created_at")
        if created and str(created).isdigit(): created = to_dt(int(created))
        rows.append({
            "Timestamp": created,"Product_Symbol": f.get("product_symbol"),"Product_ID": f.get("product_id"),
            "Side": f.get("side"),"Size": size,"Price": price,"Total_Value": total_value,
            "Commission": comm,"Role": f.get("role"),"Fill_Type": f.get("fill_type", "normal"),
            "Order_ID": f.get("order_id"),"Settling_Asset": f.get("settling_asset_symbol"),
        })
    rows.append({
        "Timestamp":"--- SUMMARY ---","Product_Symbol":"","Product_ID":"","Side":"","Size":"","Price":"",
        "Total_Value": f"Buy: {total_buy_value:.8f} | Sell: {total_sell_value:.8f}",
        "Commission": f"{total_commission:.8f}","Role":"","Fill_Type":"","Order_ID":"","Settling_Asset":"",
    })
    csv_write(fp, rows, list(rows[0].keys()) if rows else
        ["Timestamp","Product_Symbol","Product_ID","Side","Size","Price","Total_Value","Commission","Role","Fill_Type","Order_ID","Settling_Asset"])
    return fp

def pnl_summary_report(positions: List[Dict], fills: List[Dict], balances: List[Dict], outdir: str) -> str:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    fp = os.path.join(outdir, f"pnl_summary_{ts}.csv")
    total_realized = sum(float(p.get("realized_pnl", 0) or 0) for p in positions)
    total_unrealized = sum(float(p.get("unrealized_pnl", 0) or 0) for p in positions)
    total_funding_real = sum(float(p.get("realized_funding", 0) or 0) for p in positions)
    total_comm_blocked = sum(float(p.get("commission", p.get("commission_blocked", 0)) or 0) for p in positions)
    total_trade_comm = sum(abs(float(f.get("commission", 0) or 0)) for f in fills)
    total_trades = len(fills)
    bal_map = {b.get("asset_symbol"): b for b in (balances or [])}
    rows = []
    rows.append({"Metric":"=== PNL (REALIZED/UNREALIZED) ===","Value":"","Currency/Unit":""})
    rows.append({"Metric":"Realized PnL","Value":f"{total_realized:.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"Unrealized PnL","Value":f"{total_unrealized:.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"Realized Funding","Value":f"{total_funding_real:.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"Net (Realized + Funding)","Value":f"{(total_realized+total_funding_real):.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"=== CHARGES (COMMISSIONS) ===","Value":"","Currency/Unit":""})
    rows.append({"Metric":"Commission Blocked (positions)","Value":f"{total_comm_blocked:.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"Commission Paid (fills)","Value":f"{total_trade_comm:.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"Total Charges","Value":f"{(total_comm_blocked+total_trade_comm):.8f}","Currency/Unit":"native"})
    rows.append({"Metric":"=== TRADING STATS ===","Value":"","Currency/Unit":""})
    rows.append({"Metric":"Total Trades","Value":total_trades,"Currency/Unit":"count"})
    rows.append({"Metric":"=== WALLET BALANCES ===","Value":"","Currency/Unit":""})
    for sym in ("USD","USDT","BTC","ETH"):
        b = bal_map.get(sym)
        if b:
            rows.append({"Metric":f"{sym} Available","Value":b.get("available_balance"),"Currency/Unit":sym})
            rows.append({"Metric":f"{sym} Total","Value":b.get("balance"),"Currency/Unit":sym})
            rows.append({"Metric":f"{sym} Blocked Margin","Value":b.get("blocked_margin"),"Currency/Unit":sym})
    net_after_charges = total_realized + total_funding_real - total_trade_comm
    rows.append({"Metric":"=== NET AFTER CHARGES ===","Value":f"{net_after_charges:.8f}","Currency/Unit":"native"})
    csv_write(fp, rows, ["Metric","Value","Currency/Unit"])
    return fp

def generate_reports(days_back: float, outdir: str) -> List[str]:
    ensure_dir(outdir)
    API_KEY = env_str("DELTA_API_KEY", "")
    API_SECRET = env_str("DELTA_API_SECRET", "")
    BASE_URL = env_str("DELTA_BASE_URL", "https://api.india.delta.exchange")
    if not API_KEY or not API_SECRET:
        print("ERROR: DELTA_API_KEY / DELTA_API_SECRET not set in environment (.env)."); sys.exit(2)
    api = DeltaAPI(API_KEY, API_SECRET, BASE_URL)
    end_us = utcnow_us()
    start_us = end_us - int(days_back * 24 * 3600 * 1_000_000)
    print(f"[info] Range: {to_dt(start_us)} → {to_dt(end_us)}")
    positions = api.positions()
    fills     = api.fills(start_us, end_us)
    balances  = api.balances()
    reports: List[str] = []
    if positions: reports.append(open_positions_report(positions, outdir))
    else: print("[info] No open positions.")
    if fills: reports.append(trade_history_report(fills, outdir))
    else: print("[info] No fills in range.")
    reports.append(pnl_summary_report(positions, fills, balances, outdir))
    print("[ok] Generated:"); [print("  -", r) for r in reports]
    return reports

def main():
    ap = argparse.ArgumentParser(description="Delta Exchange PnL reporter (CSV outputs).")
    ap.add_argument("--days", type=float, default=1.0, help="Lookback window in days (fractional OK).")
    ap.add_argument("--outdir", type=str, default="reports", help="Output directory for CSVs.")
    args = ap.parse_args()
    generate_reports(args.days, args.outdir)

if __name__ == "__main__":
    main()

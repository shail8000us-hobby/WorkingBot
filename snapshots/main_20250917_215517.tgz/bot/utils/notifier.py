# bot/utils/notifier.py
from __future__ import annotations
import os
import time
import json
import urllib.request
import urllib.parse
import logging
from typing import Optional

log = logging.getLogger("runner")


class TelegramNotifier:
    """
    Minimal Telegram sender with retries.
    Reads token/chat_id from env if not passed.
    """

    def __init__(self, token: Optional[str] = None, chat_id: Optional[str] = None):
        self.token = token or os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        self.chat_id = chat_id or os.getenv("TELEGRAM_CHAT_ID", "").strip()
        self.enabled = os.getenv("NOTIFY_ENABLED", "1") not in (
            "0", "false", "False", "")

        if not self.token or not self.chat_id:
            # keep disabled but don't crash the bot
            self.enabled = False
            log.warning(
                "notifier: disabled (missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID)")

    def send(self, text: str):
        if not self.enabled:
            return
        try:
            url = f"https://api.telegram.org/bot{self.token}/sendMessage"
            data = urllib.parse.urlencode(
                {"chat_id": self.chat_id, "text": text}).encode()
            # 2 quick retries
            for attempt in range(2):
                try:
                    with urllib.request.urlopen(url, data=data, timeout=10) as r:
                        if r.status == 200:
                            return
                        else:
                            log.warning("notifier: http %s", r.status)
                except Exception as e:
                    if attempt == 1:
                        raise
                    time.sleep(1.0)
        except Exception as e:
            log.warning("notifier: send failed: %s", e)

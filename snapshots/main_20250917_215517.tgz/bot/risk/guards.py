import os
from decimal import Decimal


class RiskBreach(Exception):
    """Raised when a trade violates canary risk limits."""
    pass


def _to_dec(name: str, default) -> Decimal:
    v = os.getenv(name, str(default)).strip()
    return Decimal(v) if v != "" else Decimal(default)


def assert_can_trade(account_snapshot: dict, pending_open_orders: int, intended_qty, intended_price) -> None:
    """Hard-stop checks. Raise RiskBreach to block the order."""
    if os.getenv("I_UNDERSTAND_LIVE", "NO") != "YES":
        raise RiskBreach("Refusing: I_UNDERSTAND_LIVE must be YES.")
    if os.getenv("EXECUTE_ORDERS", "false").lower() != "true":
        raise RiskBreach("Execution disabled: EXECUTE_ORDERS is not true.")

    max_loss_inr = _to_dec("MAX_ACCOUNT_LOSS_INR", 1500)
    max_notional_inr = _to_dec("MAX_POSITION_NOTIONAL_INR", 1200)
    max_open_orders_cap = int(os.getenv("MAX_OPEN_ORDERS", "1"))
    max_qty_cap = _to_dec("MAX_QTY_PER_ORDER", 1)

    realized_pnl_inr = Decimal(
        str(account_snapshot.get("realized_pnl_inr", "0")))
    balance_inr = Decimal(str(account_snapshot.get("balance_inr", "0")))
    open_notional_inr = Decimal(
        str(account_snapshot.get("open_notional_inr", "0")))
    open_orders_count = int(account_snapshot.get("open_orders_count", 0))

    # 1) Absolute loss fence
    if realized_pnl_inr <= -max_loss_inr:
        raise RiskBreach("Max loss breached: killswitch.")

    # 2) Order count fence
    if open_orders_count + int(pending_open_orders) >= max_open_orders_cap:
        raise RiskBreach("Too many open orders for canary mode.")

    # 3) Quantity fence
    if Decimal(str(intended_qty)) > max_qty_cap:
        raise RiskBreach("Order qty exceeds canary limit.")

    # 4) Notional fence
    est_notional = Decimal(str(intended_qty)) * Decimal(str(intended_price))
    if open_notional_inr + est_notional > max_notional_inr:
        raise RiskBreach("Notional would exceed canary cap.")

    # 5) Balance check (optional but default ON)
    if os.getenv("REJECT_IF_NOT_ENOUGH_BAL", "true").lower() == "true":
        if balance_inr < est_notional:
            raise RiskBreach("Insufficient balance for canary order.")

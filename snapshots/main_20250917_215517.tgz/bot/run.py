import os
import sys
import logging
from dataclasses import dataclass

# --- logging ---
os.makedirs("bot/logs", exist_ok=True)
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("bot/logs/bot.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("runner")

# --- env ---
try:
    from dotenv import load_dotenv
    env_path = os.getenv("ENV_PATH", ".env")
    if os.path.exists(env_path):
        load_dotenv(env_path)
        log.info(f"env: loaded {env_path}")
    # load grid_config.env and let it override .env for grid params
    if os.path.exists("grid_config.env"):
        load_dotenv("grid_config.env", override=True)
        log.info("env: loaded grid_config.env")
except Exception as e:
    log.warning(f"dotenv load warning: {e}")

# bridge: map GRID_* → GRIDBOT_* if GRIDBOT_* are absent
def _adopt(dst: str, src: str):
    if not os.getenv(dst):
        val = os.getenv(src)
        if val is not None and val != "":
            os.environ[dst] = val

_adopt("GRIDBOT_LOWER", "GRID_LOWER")
_adopt("GRIDBOT_UPPER", "GRID_UPPER")
_adopt("GRIDBOT_STEP",  "GRID_STEP")
_adopt("GRIDBOT_REF",   "REFERENCE_LEVEL")
_adopt("GRIDBOT_LOT",   "LOT")
_adopt("GRIDBOT_MAX_OPEN", "MAX_OPEN")
_adopt("GRIDBOT_SYMBOL", "GRID_SYMBOL")  # optional if you add it later

# --- ccxt exchange setup ---
import ccxt

def make_delta():
    base = os.getenv("DELTA_BASE_URL", "https://api.india.delta.exchange").rstrip("/")
    ex = ccxt.delta({
        "apiKey": os.getenv("DELTA_API_KEY"),
        "secret": os.getenv("DELTA_API_SECRET"),
        "enableRateLimit": True,
        "options": {"defaultType": "future"},
    })
    # force base for both public/private
    ex.urls["api"] = {"public": base, "private": base}
    return ex

@dataclass
class DC:
    ex: object

# --- strategy ---
from bot.strategy.gbot_clean import run_grid_strategy

def envf(key, default):
    v = os.getenv(key, str(default))
    try:
        return type(default)(v)
    except Exception:
        return default

def main():
    # required inputs (now sourced from GRIDBOT_* which may come from grid_config.env)
    symbol   = os.getenv("GRIDBOT_SYMBOL", "BTC/USD:USD")
    lower    = envf("GRIDBOT_LOWER", 114000.0)
    upper    = envf("GRIDBOT_UPPER", 117000.0)
    step     = envf("GRIDBOT_STEP",  500.0)
    ref      = envf("GRIDBOT_REF",   116000.0)
    lot      = envf("GRIDBOT_LOT",   1)
    max_open = envf("GRIDBOT_MAX_OPEN", 5)
    hb_sec   = envf("GRIDBOT_HB_SEC", 10)

    ex = make_delta()
    try:
        markets = ex.load_markets()
        log.info(f"grid: attached ccxt handle: {ex.id}")
        log.info(f"grid: online  symbol={symbol}  LOWER={lower}  UPPER={upper}  STEP={step}  REF={ref}  LOT={float(lot)}  max_open={max_open}")
        _ = markets.get(symbol)
    except Exception as e:
        log.warning(f"ccxt init warning: {e}")

    dc = DC(ex=ex)
    run_grid_strategy(dc, symbol, lower, upper, step, ref, lot, max_open=max_open, hb_sec=hb_sec)

if __name__ == "__main__":
    sys.exit(main())

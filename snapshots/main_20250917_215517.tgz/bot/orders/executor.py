"""
Execution layer (Delta via CCXT) — single responsibility:
- Connect to exchange (India prod)
- Place/cancel orders with sane defaults
- Fetch ticker, open orders, positions
- Normalize errors and log clearly

This module is intentionally small and testable.
Higher layers (manager/protection/reconcile) should call this, not CCXT directly.
"""

from __future__ import annotations

import os
import time
import logging
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
import ccxt  # type: ignore

log = logging.getLogger("exec")

# Load environment early (ENV_PATH defaults to .env.live)
ENV_PATH = os.getenv("ENV_PATH", ".env.live")
if os.path.exists(ENV_PATH):
    load_dotenv(ENV_PATH)

DEFAULT_SYMBOL = os.getenv("DELTA_SYMBOL", "BTC/USD:USD")
API_KEY = os.getenv("DELTA_API_KEY") or ""
API_SECRET = os.getenv("DELTA_API_SECRET") or ""
USE_INDIA = True  # we’re on India production


class DeltaExecutor:
    """
    Thin wrapper around CCXT.delta with India URLs and a few conveniences
    (reduce-only, idempotent client IDs, retries).

    Safe to construct once and reuse.
    """

    def __init__(self) -> None:
        self.ex = ccxt.delta({
            "apiKey": API_KEY,
            "secret": API_SECRET,
            "enableRateLimit": True,
        })
        if USE_INDIA:
            self.ex.urls["api"] = {
                "public":  "https://api.india.delta.exchange",
                "private": "https://api.india.delta.exchange",
            }
        # Basic connectivity sanity
        try:
            # This will raise if keys/permissions/IP are invalid
            _ = self.ex.fetch_balance()
            log.info("Executor: authenticated with Delta India (CCXT ok)")
        except Exception as e:
            # We allow construction to succeed, but warn loudly;
            # callers will still get exceptions on private calls.
            log.warning("Executor: auth check failed: %s", e)

    # ---------- Market data ----------
    def fetch_ticker(self, symbol: str = DEFAULT_SYMBOL) -> Dict[str, Any]:
        return self.ex.fetch_ticker(symbol)

    # ---------- Orders ----------
    def create_order(
        self,
        side: str,
        amount: float,
        order_type: str = "market",
        symbol: str = DEFAULT_SYMBOL,
        price: Optional[float] = None,
        reduce_only: bool = False,
        client_id: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Place an order. order_type in {"market","limit"}.
        - reduce_only -> passes {'reduceOnly': True} to CCXT
        - client_id   -> passes {'clientOrderId': "..."} (idempotency hint)
        """
        if order_type not in ("market", "limit"):
            raise ValueError("order_type must be 'market' or 'limit'")
        if side not in ("buy", "sell"):
            raise ValueError("side must be 'buy' or 'sell'")
        if amount <= 0:
            raise ValueError("amount must be > 0")
        if order_type == "limit" and price is None:
            raise ValueError("price required for limit orders")

        p = dict(params or {})
        if reduce_only:
            # CCXT unified param name
            p["reduceOnly"] = True
        if client_id:
            p["clientOrderId"] = client_id

        try:
            if order_type == "market":
                order = self.ex.create_order(symbol, "market", side, amount, None, p)
            else:
                order = self.ex.create_order(symbol, "limit", side, amount, float(price), p)
            log.info(
                "EXEC: placed %s %s %s %s @ %s (reduce_only=%s cid=%s)",
                symbol, order_type, side, amount, price, reduce_only, client_id,
            )
            return order
        except Exception as e:
            log.error("EXEC: create_order failed: %s", e)
            raise

    def cancel_order(self, order_id: str, symbol: str = DEFAULT_SYMBOL) -> Dict[str, Any]:
        try:
            res = self.ex.cancel_order(order_id, symbol)
            log.info("EXEC: canceled order %s (%s)", order_id, symbol)
            return res
        except Exception as e:
            log.error("EXEC: cancel_order failed: %s", e)
            raise

    def cancel_all_orders(self, symbol: str = DEFAULT_SYMBOL) -> List[Dict[str, Any]]:
        results: List[Dict[str, Any]] = []
        try:
            open_orders = self.fetch_open_orders(symbol)
            for o in open_orders:
                try:
                    results.append(self.cancel_order(o["id"], symbol))
                except Exception as e:
                    log.warning("EXEC: cancel failed for %s: %s", o.get("id"), e)
            return results
        except Exception as e:
            log.error("EXEC: cancel_all_orders failed to list: %s", e)
            raise

    # ---------- Queries ----------
    def fetch_open_orders(self, symbol: str = DEFAULT_SYMBOL) -> List[Dict[str, Any]]:
        try:
            return self.ex.fetch_open_orders(symbol)
        except Exception as e:
            log.error("EXEC: fetch_open_orders failed: %s", e)
            raise

    def fetch_order(self, order_id: str, symbol: str = DEFAULT_SYMBOL) -> Dict[str, Any]:
        try:
            return self.ex.fetch_order(order_id, symbol)
        except Exception as e:
            log.error("EXEC: fetch_order failed: %s", e)
            raise

    def fetch_positions(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        try:
            if symbol:
                # Some CCXT builds require full fetch then filter
                ps = self.ex.fetch_positions()
                return [p for p in ps if p.get("symbol") == symbol]
            return self.ex.fetch_positions()
        except Exception as e:
            log.error("EXEC: fetch_positions failed: %s", e)
            raise

    def current_position_size(self, symbol: str = DEFAULT_SYMBOL) -> float:
        """
        Returns signed contracts if available, else 0.
        """
        try:
            ps = self.fetch_positions(symbol)
            for p in ps:
                if p.get("symbol") == symbol:
                    # CCXT standardized fields vary; try contracts/size/amount
                    sz = p.get("contracts") or p.get("size") or p.get("amount") or 0
                    try:
                        return float(sz)
                    except Exception:
                        return 0.0
        except Exception:
            pass
        return 0.0

    # ---------- Utilities ----------
    @staticmethod
    def epoch_ms() -> int:
        return int(time.time() * 1000)

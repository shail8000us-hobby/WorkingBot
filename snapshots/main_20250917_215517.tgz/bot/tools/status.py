import json
import os
from pathlib import Path

from dotenv import load_dotenv

from bot.strategy.levels import LadderCfg, build_buy_ladder


def _ensure_positions(state):
    opens = state.get("open_positions", [])
    if not isinstance(opens, (list, tuple)):
        return []
    return opens


load_dotenv()
root = Path(__file__).resolve().parents[1]
state_path = root / "state.json"
state = json.loads(state_path.read_text()) if state_path.exists() else {}
ref = state.get("reference_level")
opens = _ensure_positions(state)
total_lots = sum(float((p.get("qty") or p.get("size") or p.get("quantity") or 0) or 0) for p in _ensure_positions(state))

symbol = os.getenv("SYMBOL", "BTCUSD")
step = float(os.getenv("GRID_STEP", "2"))
lo = float(os.getenv("LOWER_BOUND", "108000"))
hi = float(os.getenv("UPPER_BOUND", "110000"))
lot_size = float(os.getenv("LOT_SIZE", "1"))
max_open = int(os.getenv("MAX_OPEN", "5"))
max_per = float(os.getenv("MAX_LOTS_PER_ORDER", "5"))
max_total = float(os.getenv("MAX_TOTAL_OPEN_LOTS", "10"))

dry_ticker = os.getenv("DELTA_DRY_TICKER", "true")
dry_orders = os.getenv("DELTA_DRY_ORDERS", "true")
execute = os.getenv("EXECUTE_ORDERS", "false")
testnet = os.getenv("DELTA_TESTNET", "true")

tick = float(os.getenv("TICK_SIZE", "0.5"))
lot_step = float(os.getenv("LOT_STEP", "1"))

ref_fallback = float(os.getenv("REFERENCE_LEVEL", "109800"))
ladder = build_buy_ladder(LadderCfg(step, lo, hi, ref if ref is not None else ref_fallback))

print(f"mode: testnet={testnet} dry_ticker={dry_ticker} dry_orders={dry_orders} execute={execute}")
print(f"strategy: {symbol} step={step} bounds=({lo},{hi}) lot_size={lot_size}")
print(f"guards: max_open={max_open} per_order_lots≤{max_per} total_open_lots≤{max_total} tick={tick} lot_step={lot_step}")
print(f"state: ref={ref} open_positions={len(_ensure_positions(state))} total_open_lots={total_lots}")
preview = ladder[:8]
print("ladder_preview:", preview, "..." if len(ladder) > 8 else "")

#!/usr/bin/env python3
from __future__ import annotations

import os, sys, json, time, threading, logging
from logging.handlers import RotatingFileHandler
from typing import Optional, List, Tuple
from dotenv import load_dotenv

# ---- env
ENV_PATH = os.getenv("ENV_PATH", ".env.live")
if os.path.exists(ENV_PATH):
    load_dotenv(ENV_PATH)

COLOR_LOGS   = os.getenv("COLOR_LOGS","true").lower() in ("1","true","yes")
HEARTBEAT_SEC= int(os.getenv("HEARTBEAT_SEC","5") or "5")
DELTA_SYMBOL = os.getenv("DELTA_SYMBOL","BTC/USD:USD")

# ---- logging
os.makedirs("bot/logs", exist_ok=True)
logging.basicConfig(
  level=getattr(logging, os.getenv("LOG_LEVEL","INFO").upper(), logging.INFO),
  format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
  datefmt="%Y-%m-%d %H:%M:%S",
  handlers=[logging.StreamHandler(sys.stdout), RotatingFileHandler("bot/logs/bot.log", maxBytes=2_000_000, backupCount=3)],
)
log = logging.getLogger("runner")

def _color(txt, code): 
    return f"\x1b[{code}m{txt}\x1b[0m" if COLOR_LOGS else txt
def _arrow(delta):
    if delta>0:  return _color(f"▲ +{delta:g}", "32")
    if delta<0:  return _color(f"▼ {delta:g}", "31")
    return _color("→ 0", "90")

def _load_state()->dict:
    try:
        with open("state.json","r") as f: return json.load(f)
    except Exception: return {}
def _save_state(d:dict)->None:
    try:
        with open("state.json","w") as f: json.dump(d,f,indent=2)
    except Exception: pass

def _resolve_product_id(symbol:str)->Optional[int]:
    try:
        from bot.api.delta_client import DeltaClient
        return DeltaClient().resolve_product_id(symbol)
    except Exception:
        return None

def _grid_levels(lo:float, hi:float, step:float, limit:int=15)->List[float]:
    try:
        if step<=0 or hi<lo: return []
        n=int(round((hi-lo)/step))+1
        lv=[lo+i*step for i in range(max(1,n))]
        return lv[:limit]+(["..."] if len(lv)>limit else [])
    except Exception: return []

def _parse_env_grid(path:str="grid_config.env"):
    if not os.path.exists(path): return None
    kv={}
    with open(path,"r") as f:
        for line in f:
            line=line.strip()
            if not line or line.startswith("#"): continue
            if "=" in line:
                k,v = line.split("=",1)
                kv[k.strip()] = v.strip()
    try:
        lo=float(kv["GRID_LOWER"]); hi=float(kv["GRID_UPPER"]); st=float(kv["GRID_STEP"])
        rf=float(kv["REFERENCE_LEVEL"]) if "REFERENCE_LEVEL" in kv else None
        lt=float(kv["LOT"]) if "LOT" in kv else None
        return (lo,hi,st,rf,lt)
    except Exception:
        return None

def _heartbeat_loop(stop_evt: threading.Event):
    import ccxt
    from dotenv import dotenv_values
    from colorama import Fore, Style

    # ccxt client
    ex = ccxt.delta({'enableRateLimit': True})
    ex.urls['api']={'public':'https://api.india.delta.exchange','private':'https://api.india.delta.exchange'}
    if os.getenv("DELTA_API_KEY") and os.getenv("DELTA_API_SECRET"):
        ex = ccxt.delta({
            'apiKey': os.getenv('DELTA_API_KEY'),
            'secret': os.getenv('DELTA_API_SECRET'),
            'enableRateLimit': True
        })
        ex.urls['api']={'public':'https://api.india.delta.exchange','private':'https://api.india.delta.exchange'}

    last_prev=None
    # track hot-reload file mtime
    cfg_path="grid_config.env"
    cfg_mtime=None

    # announce active grid from state
    s=_load_state()
    if s.get("GRID_ACTIVE"):
        lo,hi,st = float(s.get("GRID_LOWER")),float(s.get("GRID_UPPER")),float(s.get("GRID_STEP"))
        ref=s.get("REFERENCE_LEVEL"); lot=s.get("LOT")
        levels=_grid_levels(lo,hi,st)
        log.info(f"Active Grid: LOWER={lo}  UPPER={hi}  STEP={st}  REF={ref}  LOT={lot}")
        log.info(f"Grid Levels ({len(levels)}): {levels}")

    while not stop_evt.is_set():
        # ticker
        try:
            t=ex.fetch_ticker(DELTA_SYMBOL); last=t.get("last"); bid=t.get("bid"); ask=t.get("ask")
            d=(last-last_prev) if (last is not None and last_prev is not None) else 0.0
            spread=(ask-bid) if (ask is not None and bid is not None) else None
            hb=f"[HB] last={last} {_arrow(d)}  bid={bid} ask={ask}"
            if spread is not None: hb+=f" spread={spread:g}"
            hb+="  pos=0 oo=0"
            log.info(hb)
            if last is not None:
                last_prev=last
                ss=_load_state(); ss["LAST_TICK"]={"ts":int(time.time()),"last":last,"bid":bid,"ask":ask}; _save_state(ss)
        except Exception as e:
            log.warning(f"[HB] ticker failed: {e}")

        # hot reload: apply instantly if HOT_RELOAD=1 and file changed
        try:
            if os.getenv("HOT_RELOAD","0")=="1" and os.path.exists(cfg_path):
                mt=os.path.getmtime(cfg_path)
                if cfg_mtime is None:
                    cfg_mtime=mt
                elif mt>cfg_mtime:
                    cfg_mtime=mt
                    vals = dotenv_values(cfg_path)
                    # parse with fallback to current state
                    st=_load_state()
                    lo=float(vals.get("GRID_LOWER", st.get("GRID_LOWER", 0)))
                    hi=float(vals.get("GRID_UPPER", st.get("GRID_UPPER", 0)))
                    sp=float(vals.get("GRID_STEP",  st.get("GRID_STEP",  0)))
                    ref=vals.get("REFERENCE_LEVEL", st.get("REFERENCE_LEVEL"))
                    lot=vals.get("LOT", st.get("LOT"))
                    ref=float(ref) if ref is not None else None
                    lot=float(lot) if lot is not None else None
                    st.update({
                        "GRID_LOWER": lo, "GRID_UPPER": hi, "GRID_STEP": sp,
                        "REFERENCE_LEVEL": ref, "LOT": lot,
                        "GRID_ACTIVE": True, "LAST_SET_AT": int(time.time())
                    })
                    _save_state(st)
                    levels=_grid_levels(lo,hi,sp)
                    print(f"{Fore.CYAN}{Style.BRIGHT}[HOT-RELOAD] Grid UPDATED instantly: LOWER={lo} UPPER={hi} STEP={sp} REF={ref} LOT={lot} levels={levels}{Style.RESET_ALL}")
        except Exception as e:
            log.warning(f"[HB] hot-reload failed: {e}")

        stop_evt.wait(HEARTBEAT_SEC)

def main():
    log.info("=== BotPro LIVE MODE START ===")
    log.info(f"EXECUTE_ORDERS={os.getenv('EXECUTE_ORDERS','false')}  I_UNDERSTAND_LIVE={os.getenv('I_UNDERSTAND_LIVE','NO')}  MAX_ACCOUNT_LOSS_INR={os.getenv('MAX_ACCOUNT_LOSS_INR','1500')}")
    pid=_resolve_product_id(DELTA_SYMBOL)
    if pid: log.info(f"Resolved product_id={pid} for symbol={DELTA_SYMBOL}")

    stop_evt=threading.Event()
    threading.Thread(target=_heartbeat_loop, args=(stop_evt,), name="heartbeat", daemon=True).start()
    try:
        while True: time.sleep(60)
    except KeyboardInterrupt:
        pass
    finally:
        stop_evt.set()

if __name__=="__main__":
    main()

#!/usr/bin/env python3
"""
GridBot v1.1 (strict, fill-confirmed)

- Exactly ONE pending BUY (PB) at any time.
- BUY must fill first; immediately place paired TP = entry + STEP (reduce_only).
- Re-arm rule:
    * After a BUY fill @E   -> PB := max(E - STEP, LOWER)   (only if price >= LOWER)
    * After a TP  fill @T   -> PB := max(T - STEP, LOWER)
- Bounds:
    * While last > UPPER  -> HALT (no places/cancels of PB/TP); still observe fills.
    * While last < LOWER  -> do NOT place new BUYS; TPs may still fill.
- MAX_OPEN tranches cap (default 5): if reached, do not place new BUYS.
- Bot only touches its own orders (client_order_id starts with PREFIX).
- Works via the DeltaClient wrapper; it must expose a CCXT-like exchange at
  dc.ex (preferred) or dc.ccxt with: fetch_ticker, create_order, fetch_order,
  fetch_open_orders, cancel_order.
"""

from __future__ import annotations
import time, uuid, math, logging, os
from typing import Dict, Optional, List

log = logging.getLogger("runner")
PREFIX = "GBOT_"  # identify our orders

# --------- light CCXT helpers ---------

def _ex(dc):
    return next((getattr(dc, n, None) for n in ("ex","exchange","ccxt","client") if getattr(dc, n, None) is not None), None) or next((getattr(dc, n, None) for n in ("ex","exchange","ccxt","client") if getattr(dc, n, None) is not None), None)

def _ticker(dc, symbol):
    t = _ex(dc).fetch_ticker(symbol)
    # try to normalize delta/ccxt fields
    last = t.get("last")
    bid  = t.get("bid")
    ask  = t.get("ask")
    return {"last": last, "bid": bid, "ask": ask}

def _place_limit(dc, symbol, side, price, size, reduce_only=False, client_id=None):
    params = {"reduce_only": reduce_only} if reduce_only else {}
    if client_id:
        # delta uses clientOrderId in ccxt
        params["clientOrderId"] = client_id
    o = _ex(dc).create_order(symbol, "limit", side, size, price, params)
    return o  # ccxt order dict with id

def _fetch_order(dc, id, symbol):
    return _ex(dc).fetch_order(id, symbol)

def _open_orders(dc, symbol) -> List[dict]:
    return _ex(dc).fetch_open_orders(symbol)

def _cancel(dc, id, symbol):
    try:
        _ex(dc).cancel_order(id, symbol)
    except Exception as e:
        # If already filled or gone, that's fine.
        if "order_not_found" not in str(e).lower():
            raise

def _is_ours(o: dict) -> bool:
    coid = o.get("clientOrderId") or o.get("client_order_id")
    return bool(coid and str(coid).startswith(PREFIX))

def _price(o: dict) -> Optional[float]:
    p = o.get("price")
    try:
        return float(p) if p is not None else None
    except:
        return None

def _is_reduce_only(o: dict) -> bool:
    ro = o.get("reduce_only")
    if ro is None:
        # some adapters put it under 'info'
        ro = (o.get("info") or {}).get("reduce_only")
    return bool(ro)

def _status(o: dict) -> str:
    return (o.get("status") or "").lower()

# --------- core strategy ---------

def rung_for(price: float, ref: float, step: float) -> int:
    """N for which ref - N*step == price"""
    return int(round((ref - price) / step))

def price_for_rung(N: int, ref: float, step: float) -> float:
    return ref - N * step

def within(x, lo, hi):
    return (x is not None) and (lo <= x <= hi)

def nearly_equal(a, b, eps=1e-9):
    return a is not None and b is not None and abs(a - b) < eps

class GridBot:
    def __init__(self, dc, symbol: str, lower: float, upper: float, step: float,
                 ref: float, lot: float, max_open: int = 5, hb_sec: int = 5):
        self.dc = dc
        self.symbol = symbol
        self.lower = float(lower)
        self.upper = float(upper)
        self.step  = float(step)
        self.ref   = float(ref)
        self.lot   = float(lot)
        self.max_open = int(max_open)
        self.hb_sec = int(hb_sec)

        # runtime state
        self.pending_buy_price: Optional[float] = max(self.ref - self.step, self.lower)
        self.open_tranches: Dict[str, Dict] = {}  # buy_id -> {entry, tp_id?}
        self.halted = False

    # ----- PB management -----

    def _arm_pb(self, px: Optional[float]):
        if px is None: return
        px = max(px, self.lower)
        self.pending_buy_price = px

    def _ensure_one_pb(self, last):
        """Keep exactly one pending BUY at PB price (unless halted or <lower or max_open hit)."""
        oo = _open_orders(self.dc, self.symbol)
        mine = [o for o in oo if _is_ours(o)]
        # split by role
        buys  = [o for o in mine if o.get("side") == "buy"  and not _is_reduce_only(o)]
        sells = [o for o in mine if o.get("side") == "sell" and _is_reduce_only(o)]  # our TPs

        # reconcile PB target against rules
        if last > self.upper:
            # HALT: do not place/cancel anything PB/TP
            self.halted = True
            return
        self.halted = False

        # if below LOWER -> do not place new BUYs
        if last < self.lower:
            return

        # if already at/max open tranches, do not place new PB
        if len(self.open_tranches) >= self.max_open:
            return

        # target PB price
        pb = self.pending_buy_price
        if pb is None:
            return

        # cancel any extra BUYs not at pb (safety)
        for o in buys:
            opx = _price(o)
            if not nearly_equal(opx, pb):
                _cancel(self.dc, o["id"], self.symbol)
                log.info("grid: canceled stray BUY %s @ %.1f", o["id"], opx)

        # ensure there is exactly one BUY at pb
        exists = next((o for o in buys if nearly_equal(_price(o), pb)), None)
        if exists is None:
            # place it
            cid = f"{PREFIX}B_{uuid.uuid4().hex[:10]}_{int(pb)}"
            try:
                o = _place_limit(self.dc, self.symbol, "buy", pb, self.lot, reduce_only=False, client_id=cid)
                log.info("grid: placed BUY %.1f @ %.1f (id=%s)", self.lot, pb, o.get("id"))
            except Exception as e:
                log.warning("grid: place BUY @ %.1f failed: %s", pb, e)

    # ----- poll fills -----

    def _reconcile_fills(self):
        """Check our known tranche orders for fills, act accordingly."""
        # First, see if any known BUYs finished
        for buy_id, tr in list(self.open_tranches.items()):
            if tr.get("entry_filled") is True:
                continue  # already handled

            try:
                od = _fetch_order(self.dc, buy_id, self.symbol)
            except Exception:
                continue

            st = _status(od)
            if st in ("closed", "filled"):
                tr["entry_filled"] = True
                entry = float(od.get("price") or tr["entry"])
                tr["entry"] = entry
                # place TP immediately (reduce_only)
                tp_price = entry + self.step
                cid = f"{PREFIX}S_{uuid.uuid4().hex[:10]}_{int(tp_price)}"
                try:
                    tp = _place_limit(self.dc, self.symbol, "sell", tp_price, self.lot,
                                      reduce_only=True, client_id=cid)
                    tr["tp_id"] = tp.get("id")
                    tr["tp_price"] = tp_price
                    log.info("grid: TP placed reduce_only @ %.1f (tp_id=%s) for BUY id=%s",
                             tp_price, tr["tp_id"], buy_id)
                except Exception as e:
                    log.warning("grid: failed to place TP @ %.1f for BUY id=%s: %s",
                                tp_price, buy_id, e)
                # as soon as a BUY fills, re-arm PB one rung lower (bounded)
                self._arm_pb(entry - self.step)

        # Next, see if any TP finished
        for buy_id, tr in list(self.open_tranches.items()):
            tp_id = tr.get("tp_id")
            if not tp_id:
                continue
            try:
                od = _fetch_order(self.dc, tp_id, self.symbol)
            except Exception:
                continue
            st = _status(od)
            if st in ("closed", "filled"):
                # tranche complete
                tp_px = float(od.get("price") or tr["tp_price"])
                # Re-arm PB one rung below TP
                self._arm_pb(tp_px - self.step)
                log.info("grid: TP filled @ %.1f for BUY id=%s; re-arm PB -> %.1f",
                         tp_px, buy_id, self.pending_buy_price)
                self.open_tranches.pop(buy_id, None)

    # ----- discover new BUY fills that we didn’t record placing -----

    def _capture_new_buys(self):
        """If our one PB fills, grab its id from open orders set difference."""
        oo = _open_orders(self.dc, self.symbol)
        mine = [o for o in oo if _is_ours(o)]
        # any *open* buy that we do not yet track as tranche?
        for o in mine:
            if o.get("side") != "buy" or _is_reduce_only(o):
                continue
            if any(o["id"] == k for k in self.open_tranches.keys()):
                continue
            # new entry (pending but open), record it
            px = _price(o) or self.pending_buy_price
            self.open_tranches[o["id"]] = {"entry": px, "entry_filled": False}
            # do not modify PB here; it will be adjusted only when this entry fills

    # ----- main loop -----

    def run(self):
        hb = max(1, self.hb_sec)
        while True:
            try:
                t = _ticker(self.dc, self.symbol)
                last = t["last"]
# #                log.info("[HB] last=%.1f", last)

                # observe fills first
                self._reconcile_fills()
                self._capture_new_buys()

                # manage the single pending buy
                self._ensure_one_pb(last)

            except Exception as e:
                log.warning("grid: loop error: %s", e)
            time.sleep(hb)

# public API
def run_grid_strategy(dc, symbol, lower, upper, step, ref, lot, max_open=5, hb_sec=5):
    ex_attr = next((n for n in ("ex","exchange","ccxt","client") if getattr(dc, n, None) is not None), None)
    log.info("grid: using CCXT handle via dc.%s", ex_attr)
    bot = GridBot(dc, symbol, lower, upper, step, ref, lot, max_open=max_open, hb_sec=hb_sec)
    log.info("grid: online  symbol=%s  LOWER=%s  UPPER=%s  STEP=%s  REF=%s  LOT=%s  max_open=%s",
             symbol, lower, upper, step, ref, lot, max_open)
    bot.run()

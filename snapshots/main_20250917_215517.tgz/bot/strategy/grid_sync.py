import os, json, time, typing
import ccxt

SYMBOL = os.getenv("DELTA_SYMBOL", "BTC/USD:USD")

# Non-grid knobs still from env (these are not part of grid_config.env)
MAX_RUNGS    = int(os.getenv("MAX_CONCURRENT_TRANCHES", "5"))
SYNC_SEC     = float(os.getenv("GRID_SYNC_SEC", "10"))
COOLDOWN_SEC = SYNC_SEC * 2
LOT_DEFAULT  = float(os.getenv("LOT", "1"))  # fallback if state.json missing LOT

CID_PREFIX = "GBOT_"

def _now_ms() -> int:
    return int(time.time() * 1000)

def _client() -> ccxt.Exchange:
    ex = ccxt.delta({
        'apiKey': os.getenv('DELTA_API_KEY'),
        'secret': os.getenv('DELTA_API_SECRET'),
        'enableRateLimit': True
    })
    ex.urls['api'] = {
        'public':  'https://api.india.delta.exchange',
        'private': 'https://api.india.delta.exchange'
    }
    return ex

def _load_state() -> dict:
    try:
        with open("state.json", "r") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_state(d: dict) -> None:
    try:
        with open("state.json", "w") as f:
            json.dump(d, f, indent=2)
    except Exception:
        pass

def _grid_from_state(state: dict) -> typing.Tuple[float, float, float, float, float]:
    """Return (LOWER, UPPER, STEP, REF, LOT) strictly from state.json with safe fallbacks."""
    LOWER = float(state.get("GRID_LOWER")) if state.get("GRID_LOWER") is not None else 100000.0
    UPPER = float(state.get("GRID_UPPER")) if state.get("GRID_UPPER") is not None else 112500.0
    STEP  = float(state.get("GRID_STEP"))  if state.get("GRID_STEP")  is not None else 500.0
    REF   = float(state.get("REFERENCE_LEVEL")) if state.get("REFERENCE_LEVEL") is not None else 108800.0
    LOT   = float(state.get("LOT")) if state.get("LOT") is not None else LOT_DEFAULT
    return LOWER, UPPER, STEP, REF, LOT

def _get_ticker(ex) -> dict:
    try:
        return ex.fetch_ticker(SYMBOL) or {}
    except Exception:
        return {}

def _our(order: dict) -> bool:
    cid = order.get('clientOrderId') or (order.get('info') or {}).get('client_order_id')
    return isinstance(cid, str) and cid.startswith(CID_PREFIX)

def _our_open_orders(ex) -> list:
    try:
        oo = ex.fetch_open_orders(SYMBOL) or []
    except Exception:
        oo = []
    return [o for o in oo if _our(o)]

def _fetch_order(ex, order_id: str) -> typing.Optional[dict]:
    try:
        return ex.fetch_order(order_id, SYMBOL)
    except Exception:
        return None

def _place_limit_buy(ex, price: float, lot: float, log) -> typing.Optional[str]:
    cid = f"{CID_PREFIX}{_now_ms()}_BUY"
    try:
        o = ex.create_order(
            SYMBOL, type="limit", side="buy", amount=lot, price=price,
            params={"clientOrderId": cid, "client_order_id": cid}
        )
        log.info(f"grid: placed BUY {lot} @ {price} (id={o.get('id')})")
        return o.get('id') or None
    except Exception as e:
        log.warning(f"grid: place BUY @ {price} failed: {e}")
        return None

def _ensure_reduce_only_tp(ex, tranche: dict, step: float, lot: float, log) -> None:
    target = float(tranche['entry']) + step
    oo = _our_open_orders(ex)
    # keep an existing correct TP if present
    for o in oo:
        if o.get('side') != 'sell':
            continue
        px = o.get('price')
        try:
            px = float(px) if px is not None else None
        except Exception:
            px = None
        if px is not None and abs(px - target) < 1e-9:
            tranche['tp_id'] = o.get('id')
            return
    # else create it
    cid = f"{CID_PREFIX}{_now_ms()}_TP"
    try:
        o = ex.create_order(
            SYMBOL, type="limit", side="sell", amount=lot, price=target,
            params={"reduce_only": True, "clientOrderId": cid, "client_order_id": cid}
        )
        tranche['tp_id'] = o.get('id')
        log.info(f"grid: placed TP SELL {lot} @ {target} reduce_only (id={tranche['tp_id']})")
    except Exception as e:
        log.warning(f"grid: place TP SELL @ {target} failed: {e}")

def _cancel(ex, order_id: str, log) -> None:
    try:
        ex.cancel_order(order_id, SYMBOL)
        log.info(f"grid: canceled stray order {order_id}")
    except Exception as e:
        log.warning(f"grid: cancel failed for {order_id}: {e}")

def _clean_book(ex, want_buy_px: typing.Optional[float], step: float, tranches: list, log) -> None:
    wanted_sell = set(float(t['entry']) + step for t in tranches)
    oo = _our_open_orders(ex)
    kept_buy = False
    for o in oo:
        side = o.get('side')
        price = o.get('price')
        try:
            price = float(price) if price is not None else None
        except Exception:
            price = None
        keep = False
        if side == 'buy' and want_buy_px is not None and price is not None:
            if abs(price - want_buy_px) < 1e-9 and not kept_buy:
                kept_buy = True
                keep = True
        elif side == 'sell' and price is not None:
            if any(abs(price - ws) < 1e-9 for ws in wanted_sell):
                keep = True
        if not keep and o.get('id'):
            _cancel(ex, o['id'], log)

def _active(last: float, lower: float, upper: float) -> bool:
    return last is not None and (lower <= last <= upper)

def _next_entry_price(tranches: list, ref: float, step: float) -> float:
    if not tranches:
        return ref - step
    lowest = min(float(t['entry']) for t in tranches)
    return lowest - step

def _within_bounds(px: float, lower: float) -> bool:
    return px >= lower

def _tranches(state: dict, lot: float) -> list:
    arr = state.get("LADDER")
    if isinstance(arr, list):
        for t in arr:
            t.setdefault('size', lot)
            t.setdefault('tp_id', None)
            t.setdefault('created_at', _now_ms())
        return arr
    return []

def _set_tranches(state: dict, arr: list) -> None:
    state["LADDER"] = arr

def _pending_entry(state: dict) -> dict:
    pe = state.get("PENDING_ENTRY")
    if isinstance(pe, dict):
        return pe
    return {"price": None, "order_id": None}

def _set_pending_entry(state: dict, price: typing.Optional[float], order_id: typing.Optional[str]) -> None:
    state["PENDING_ENTRY"] = {"price": price, "order_id": order_id}

def sync_once(state: dict, log) -> None:
    """
    Reads grid strictly from state.json (populated by dashboard/set_grid.sh).
    Maintains one pending BUY at next rung, and one reduce-only TP per filled tranche.
    Respects active range and max concurrent tranches.
    """
    # Always re-load state (hot grid changes)
    cur = _load_state()
    state.update(cur)  # merge into live state

    LOWER, UPPER, STEP, REF, LOT = _grid_from_state(state)

    ex = _client()
    t = _get_ticker(ex)
    last = t.get('last')
    try:
        last = float(last) if last is not None else None
    except Exception:
        last = None

    active = _active(last, LOWER, UPPER)
    state["ACTIVE"] = bool(active)
    if not active:
        _save_state(state)
        return

    if STEP <= 0 or LOT <= 0 or UPPER <= LOWER:
        _save_state(state)
        return

    now = time.time()
    cd_until = state.get("COOLDOWN_UNTIL")
    if isinstance(cd_until, (int, float)) and now < cd_until:
        _save_state(state)
        return

    ladder = _tranches(state, LOT)
    pending = _pending_entry(state)

    # Track/ingest pending order status (did it fill/cancel?)
    if pending.get("order_id"):
        od = _fetch_order(ex, pending["order_id"])
        if od:
            status = (od.get('status') or '').lower()
            filled = float(od.get('filled') or 0.0)
            px = od.get('price')
            try:
                px = float(px) if px is not None else pending.get("price")
            except Exception:
                px = pending.get("price")
            if status == "closed" and filled > 0:
                ladder.append({"entry": float(px), "size": LOT, "tp_id": None, "created_at": _now_ms()})
                log.info(f"grid: BUY filled @ {px}; armed tranche count = {len(ladder)}")
                pending = {"price": None, "order_id": None}
            elif status == "canceled":
                log.info("grid: pending BUY canceled; will re-arm if needed")
                pending = {"price": None, "order_id": None}

    # Ensure exactly one reduce-only TP per tranche
    for tr in ladder:
        _ensure_reduce_only_tp(ex, tr, STEP, LOT, log)

    # Respect max concurrent tranches
    if len(ladder) >= MAX_RUNGS:
        if pending.get("order_id"):
            od = _fetch_order(ex, pending["order_id"])
            if od and (od.get('status') or '').lower() == 'open':
                _cancel(ex, pending["order_id"], log)
        pending = {"price": None, "order_id": None}
        _set_tranches(state, ladder)
        _set_pending_entry(state, pending.get("price"), pending.get("order_id"))
        _save_state(state)
        return

    # Compute next rung from state grid
    next_px = _next_entry_price(ladder, REF, STEP)
    if not _within_bounds(next_px, LOWER):
        _clean_book(ex, None, STEP, ladder, log)  # keep TPs only
        _set_tranches(state, ladder)
        _set_pending_entry(state, None, None)
        _save_state(state)
        return

    # Keep book minimal (one BUY at next_px + TPs)
    _clean_book(ex, next_px, STEP, ladder, log)

    # If pending BUY already open at next_px, we're good
    if pending.get("order_id"):
        od = _fetch_order(ex, pending["order_id"])
        if od and (od.get('status') or '').lower() == 'open':
            try:
                od_px = float(od.get('price') or next_px)
            except Exception:
                od_px = next_px
            if abs(od_px - next_px) < 1e-9:
                _set_tranches(state, ladder)
                _set_pending_entry(state, next_px, pending["order_id"])
                _save_state(state)
                return
            else:
                _cancel(ex, pending["order_id"], log)
                pending = {"price": None, "order_id": None}

    # Place new pending BUY at next_px
    new_id = _place_limit_buy(ex, next_px, LOT, log)
    if new_id is None:
        state["COOLDOWN_UNTIL"] = time.time() + COOLDOWN_SEC
        log.warning(f"grid: entering cooldown until {state['COOLDOWN_UNTIL']:.0f}")
        _set_tranches(state, ladder)
        _set_pending_entry(state, None, None)
        _save_state(state)
        return

    _set_tranches(state, ladder)
    _set_pending_entry(state, next_px, new_id)
    _save_state(state)

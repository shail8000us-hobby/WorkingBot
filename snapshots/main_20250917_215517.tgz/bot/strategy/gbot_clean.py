# GridBot v2.0.0 — Delta Exchange Production Ready (clean)

from __future__ import annotations
import os
import time
import logging
import traceback
from typing import Any, Dict, List, Optional, Tuple, Union

log = logging.getLogger("runner")

def sym(s: str) -> str:
    """Identity mapping to avoid accidental symbol concatenation."""
    return s

# --- Colors (safe fallback if missing utils/colors.py) ---
try:
    from bot.utils.colors import green, red, cyan, orange
except Exception:
    def _wrap(code: str):
        def _c(s: str) -> str:
            return f"\033[{code}m{s}\033[0m"
        return _c
    green, red, cyan, orange = _wrap("92"), _wrap("91"), _wrap("96"), _wrap("38;5;208")

# --- Configurable constants ---
TICK_SIZE = float(os.getenv("GRIDBOT_TICK_SIZE", "0.5"))
FILL_THRESHOLD = float(os.getenv("GRIDBOT_FILL_THRESHOLD", "0.98"))
MAX_RETRIES = int(os.getenv("GRIDBOT_MAX_RETRIES", "3"))
RETRY_DELAY = float(os.getenv("GRIDBOT_RETRY_DELAY", "2.0"))
COOLDOWN_SECONDS = int(os.getenv("GRIDBOT_COOLDOWN_SECONDS", "30"))
GBOT_PREFIX = os.getenv("GRIDBOT_TAG_PREFIX", "GBOT_")

# Rate limiting constants (soft)
API_WEIGHT_LIMIT = 10000
HEARTBEAT_MIN_INTERVAL = 10
ORDER_WEIGHT = 5
TICKER_WEIGHT = 3

# --- Utilities ---
def _now_ms() -> int:
    return int(time.time() * 1000)

def _fmt_px(x: Union[float, int, None]) -> str:
    if x is None:
        return "N/A"
    try:
        return f"{float(x):.1f}"
    except (ValueError, TypeError):
        return "N/A"

def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        return float(v)
    except Exception:
        return default

def _safe_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default

def _within_band(px: float, lo: float, hi: float) -> bool:
    return lo <= px <= hi

def _grid_next_after_start(ref: float, step: float) -> float:
    return ref - step

def _tp_for_entry(entry_px: float, step: float) -> float:
    return entry_px + step

def _next_lower_after_buy(entry_px: float, step: float) -> float:
    return entry_px - step

def _session_tag() -> str:
    return f"{GBOT_PREFIX}{int(time.time())}"

def _has_ccxt(dc: Any) -> Any:
    for name in ("ex", "exchange", "ccxt", "client"):
        ex = getattr(dc, name, None)
        if ex is not None:
            return ex
    return None

def _is_delta(ex: Any) -> bool:
    try:
        return getattr(ex, "id", "") == "delta"
    except Exception:
        return False

def _is_rate_limit_error(e: Exception) -> bool:
    s = str(e).lower()
    return any(k in s for k in ("rate limit", "too many requests", "429", "throttle", "limit exceeded"))

def _retry_operation(func, *args, max_retries: int = MAX_RETRIES, delay: float = RETRY_DELAY, **kwargs):
    last_exception = None
    for attempt in range(max_retries):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            last_exception = e
            if attempt < max_retries - 1:
                wait = delay * (2 ** attempt) if not _is_rate_limit_error(e) else delay * (3 ** attempt)
                log.warning(f"Operation retry {attempt+1}/{max_retries} in {wait:.1f}s: {e}")
                time.sleep(wait)
            else:
                log.error(f"Operation failed after {max_retries} attempts: {e}")
    raise last_exception if last_exception else RuntimeError("Retry operation failed")

class GridBot:
    """GridBot v2.0.0 — Delta Exchange Production Ready (clean)"""

    def __init__(self, dc, symbol: str, lower: float, upper: float, step: float,
                 ref: float, lot: Union[int, float], max_open: int = 5, hb_sec: int = 10):

        self.log = logging.getLogger("runner")
        self.dc, self.ex = dc, _has_ccxt(dc)
        if not self.ex:
            raise ValueError("CCXT exchange handle not found in dc object")

        self._validate_and_set_params(symbol, lower, upper, step, ref, lot, max_open, hb_sec)

        self.is_delta_exchange = _is_delta(self.ex)
        if not self.is_delta_exchange:
            log.warning("Exchange is not Delta - some features may not work correctly")

        self.product_id = self._get_product_id()
        if self.is_delta_exchange and not self.product_id:
            raise ValueError(f"Could not find product_id for symbol {self.symbol}")

        self._initialize_state()

        log.info(f"GridBot v2.0.0 initialized for {self.symbol} (product_id: {self.product_id})")
        log.info(f"Grid: {_fmt_px(self.lower)} - {_fmt_px(self.ref)} - {_fmt_px(self.upper)}, "
                 f"step: {_fmt_px(self.step)}, lot: {self.lot}")

        self._bootstrap_state()

    def _validate_and_set_params(self, symbol: str, lower: float, upper: float,
                                 step: float, ref: float, lot: Union[int, float],
                                 max_open: int, hb_sec: int):
        self.symbol = str(symbol).strip()
        if not self.symbol:
            raise ValueError("Symbol cannot be empty")
        self.symbol_ccxt = self.symbol

        self.lower = _safe_float(lower)
        self.upper = _safe_float(upper)
        self.step = _safe_float(step)
        self.ref = _safe_float(ref)

        original_lot = _safe_float(lot)
        self.lot = int(original_lot)
        if self.lot != original_lot and original_lot > 0:
            log.warning(f"Lot size {original_lot} rounded to {self.lot} (Delta requires integers)")

        self.max_open = max(1, min(_safe_int(max_open, 5), 10))
        self.hb_sec = max(HEARTBEAT_MIN_INTERVAL, _safe_int(hb_sec, 10))

        if self.step <= 0:
            raise ValueError("Step must be positive")
        if self.lower >= self.upper:
            raise ValueError("Lower bound must be less than upper bound")
        if not _within_band(self.ref, self.lower, self.upper):
            raise ValueError("Reference price must be within bounds")
        if self.lot <= 0:
            raise ValueError("Lot size must be positive")

    def _initialize_state(self):
        self.session_tag = _session_tag()
        self.open_tranches: List[Dict[str, Any]] = []
        self.pending_buy: Optional[Dict[str, Any]] = None
        self.last_trades_since: Optional[int] = None
        self.cooldown_until = 0
        self._active_client_ids: set[str] = set()
        self._last_ticker: Dict[str, float] = {}
        self._api_call_count = 0
        self._window_start = time.time()

    def _get_product_id(self) -> Optional[int]:
        if not self.is_delta_exchange or not self.ex:
            return None
        try:
            market = _retry_operation(self.ex.market, self.symbol_ccxt, max_retries=2)
        except Exception as e:
            log.warning(f"Direct market lookup failed: {e}")
            market = None
        if not market:
            try:
                markets = _retry_operation(self.ex.load_markets, max_retries=2) or {}
                market = markets.get(self.symbol_ccxt)
            except Exception as e:
                log.error(f"Failed to load markets: {e}")
                return None
        if not market:
            log.error(f"Market not found for symbol {self.symbol_ccxt}")
            return None
        info = market.get("info", {})
        for val in (info.get("product_id"), info.get("productId"), market.get("numericId")):
            if isinstance(val, int) and val > 0:
                return val
            if isinstance(val, str) and val.isdigit():
                return int(val)
        log.error(f"Could not extract product_id from market data for {self.symbol_ccxt}")
        return None

    # simple soft limiter
    def _check_rate_limit(self):
        now = time.time()
        if now - self._window_start > 300:
            self._api_call_count = 0
            self._window_start = now
        if self._api_call_count > (API_WEIGHT_LIMIT * 0.8):
            wait_time = 300 - (now - self._window_start)
            if wait_time > 0:
                log.warning(f"Rate limit approaching, waiting {wait_time:.1f}s")
                time.sleep(wait_time)
                self._api_call_count = 0
                self._window_start = time.time()

    def _track_api_call(self, weight: int = 1):
        self._api_call_count += weight

    def _bootstrap_state(self):
        log.info("GridBot: Bootstrapping state from existing orders...")
        try:
            self._check_rate_limit()
            open_orders = _retry_operation(self.ex.fetch_open_orders, self.symbol_ccxt)
            self._track_api_call(3)
        except Exception as e:
            log.error(f"Bootstrap: Failed to fetch open orders: {e}")
            open_orders = []

        if not open_orders:
            log.info("Bootstrap: No existing orders found")
            self.last_trades_since = _now_ms() - 60_000
            return

        buys, sells = [], []
        for order in open_orders:
            try:
                client_id = self._get_client_order_id(order)
                if client_id and client_id.startswith(GBOT_PREFIX):
                    self._active_client_ids.add(client_id)
                    side = str(order.get("side", "")).lower()
                    if side == "buy":
                        buys.append(order)
                    elif side == "sell":
                        sells.append(order)
            except Exception as e:
                log.warning(f"Bootstrap: Error processing order {order.get('id', '?')}: {e}")

        restored_tranches = 0
        for sell_order in sells:
            try:
                if not self._is_reduce_only(sell_order):
                    continue
                tp_price = _safe_float(sell_order.get("price"))
                if tp_price <= 0:
                    continue
                entry_price = tp_price - self.step
                steps_from_ref = round((self.ref - entry_price) / self.step)
                expected_entry = self.ref - steps_from_ref * self.step
                if abs(entry_price - expected_entry) > TICK_SIZE:
                    continue
                if not _within_band(entry_price, self.lower, self.ref):
                    continue
                client_id = self._get_client_order_id(sell_order)
                self.open_tranches.append({
                    "buy_px": entry_price,
                    "qty": self.lot,
                    "tp_px": tp_price,
                    "tp_id": sell_order.get("id"),
                    "tp_client_id": client_id or ""
                })
                restored_tranches += 1
            except Exception as e:
                log.warning(f"Bootstrap: Error processing TP order {sell_order.get('id', '?')}: {e}")

        if buys:
            try:
                buy_order = min(buys, key=lambda x: _safe_float(x.get("price", 0)))
                self.pending_buy = {
                    "px": _safe_float(buy_order.get("price")),
                    "order_id": buy_order.get("id"),
                    "client_id": self._get_client_order_id(buy_order)
                }
            except Exception as e:
                log.warning(f"Bootstrap: Error restoring pending buy: {e}")

        self.last_trades_since = _now_ms() - 60_000
        log.info(orange(f"GridBot: Bootstrap complete - restored {restored_tranches} tranches, "
                        f"pending buy: {bool(self.pending_buy)}"))

    def run(self):
        log.info(orange(f"GridBot: Starting main loop for {self.symbol}"))
        last_price = None
        consecutive_errors = 0
        max_consecutive_errors = 10

        while True:
            try:
                self._tick()
                try:
                    ticker = self._fetch_ticker_safe()
                    if ticker:
                        current_price = ticker.get("last", 0)
                        bid, ask = ticker.get("bid", 0), ticker.get("ask", 0)
                        price_change = ""
                        if last_price is not None and current_price > 0:
                            diff = current_price - last_price
                            if abs(diff) >= 0.1:
                                price_change = green(f" ▲ +{_fmt_px(diff)}") if diff > 0 else red(f" ▼ {_fmt_px(diff)}")
                        last_price = current_price
                        open_count = len(self.open_tranches)
                        exposure = open_count * self.lot
                        pending_info = f" | pending: {_fmt_px(self.pending_buy['px'])}" if self.pending_buy else ""
                        log.info(
                            f"[HB] {self.symbol}: {_fmt_px(current_price)}{price_change} | "
                            f"bid: {green(_fmt_px(bid))} ask: {cyan(_fmt_px(ask))} | "
                            f"positions: {open_count}/{self.max_open} (exposure: {exposure}){pending_info}"
                        )
                        self._last_ticker = ticker
                except Exception as e:
                    log.warning(f"Heartbeat error: {e}")
                consecutive_errors = 0
                time.sleep(self.hb_sec)
            except KeyboardInterrupt:
                log.info("GridBot: Stopped by user")
                self._cleanup_on_exit()
                break
            except Exception as e:
                consecutive_errors += 1
                log.error(f"GridBot: Loop error ({consecutive_errors}/{max_consecutive_errors}): {e}")
                if log.isEnabledFor(logging.DEBUG):
                    log.debug(traceback.format_exc())
                if consecutive_errors >= max_consecutive_errors:
                    log.critical("GridBot: Too many consecutive errors, exiting")
                    break
                time.sleep(min(self.hb_sec * consecutive_errors, 60))

    def _fetch_ticker_safe(self) -> Optional[Dict[str, float]]:
        try:
            self._check_rate_limit()
            ticker = self.ex.fetch_ticker(self.symbol_ccxt) or {}
            self._track_api_call(TICKER_WEIGHT)
            return {k: _safe_float(ticker.get(k)) for k in ("last", "bid", "ask", "high", "low", "open", "close")}
        except Exception as e:
            log.warning(f"Ticker fetch failed: {e}")
            return None

    def _tick(self):
        for op_name, op_func in (
            ("confirm_pending_buy", self._confirm_pending_buy),
            ("confirm_tp_fills", self._confirm_tp_fills),
            ("ensure_pending_buy", self._ensure_pending_buy),
        ):
            try:
                op_func()
            except Exception as e:
                log.error(f"Tick operation '{op_name}' failed: {e}")

    def _confirm_pending_buy(self):
        if not self.pending_buy:
            return
        pending = self.pending_buy
        confirmed = False
        avg_price = _safe_float(pending["px"])
        fill_info: List[str] = []
        try:
            confirmed, avg_price, fill_info = self._try_confirm_by_trades(pending)
        except Exception as e:
            log.warning(f"Trade confirmation failed: {e}")
        if not confirmed and not self.is_delta_exchange:
            try:
                confirmed, avg_price = self._try_confirm_by_order(pending)
            except Exception as e:
                log.warning(f"Order confirmation failed: {e}")
        if not confirmed:
            return
        tp_price = _tp_for_entry(avg_price, self.step)
        try:
            tp_id, tp_client_id = self._place_tp_sell(tp_price)
            if tp_id:
                self.open_tranches.append({
                    "buy_px": avg_price,
                    "qty": self.lot,
                    "buy_id": pending.get("order_id"),
                    "buy_client_id": pending.get("client_id", ""),
                    "tp_px": tp_price,
                    "tp_id": tp_id,
                    "tp_client_id": tp_client_id or ""
                })
                log.info(green(
                    f"GridBot: BUY confirmed @{_fmt_px(avg_price)} "
                    f"(order: {pending.get('order_id')}) → TP @{_fmt_px(tp_price)}"
                ))
                cid = pending.get("client_id", "")
                if cid:
                    self._active_client_ids.discard(cid)
                self.pending_buy = None
                if len(self.open_tranches) < self.max_open:
                    next_price = _next_lower_after_buy(avg_price, self.step)
                    if next_price >= self.lower:
                        self._ensure_pending_at_price(next_price)
            else:
                log.error("TP placement failed; keeping pending buy for retry")
        except Exception as e:
            log.error(f"Error after buy confirmation: {e}")

    def _confirm_tp_fills(self):
        if not self.open_tranches:
            return
        try:
            self._check_rate_limit()
            trades = _retry_operation(self.ex.fetch_my_trades, self.symbol_ccxt, self.last_trades_since, max_retries=2)
            self._track_api_call(10)
            if trades:
                latest_ts = max((_safe_int(tr.get("timestamp")) for tr in trades), default=0)
                self.last_trades_since = max(self.last_trades_since or 0, latest_ts + 1)
            else:
                self.last_trades_since = _now_ms()
        except Exception as e:
            log.warning(f"Fetch trades failed: {e}")
            return
        tp_by_id = {t["tp_id"]: t for t in self.open_tranches if t.get("tp_id")}
        filled_tp_ids: List[str] = []
        for tr in trades or []:
            try:
                if str(tr.get("side", "")).lower() != "sell":
                    continue
                oid = self._get_trade_order_id(tr)
                if oid and oid in tp_by_id:
                    filled_tp_ids.append(oid)
            except Exception as e:
                log.warning(f"Trade processing error {tr.get('id', '?')}: {e}")
        for tp_id in filled_tp_ids:
            try:
                tranche = tp_by_id[tp_id]
                entry_price = _safe_float(tranche["buy_px"])
                tp_price = _safe_float(tranche["tp_px"])
                tp_client_id = tranche.get("tp_client_id", "")
                if tp_client_id:
                    self._active_client_ids.discard(tp_client_id)
                self.open_tranches = [t for t in self.open_tranches if t.get("tp_id") != tp_id]
                log.info(green(
                    f"GridBot: TP FILLED @{_fmt_px(tp_price)} (entry: {_fmt_px(entry_price)}) - PROFIT TAKEN"
                ))
                self._cancel_pending_if_any()
                if _within_band(entry_price, self.lower, self.upper):
                    self._ensure_pending_at_price(entry_price)
            except Exception as e:
                log.error(f"Error processing filled TP {tp_id}: {e}")

    def _ensure_pending_buy(self):
        if (time.time() < self.cooldown_until or self.pending_buy or
            len(self.open_tranches) >= self.max_open):
            return
        current_price = self._last_ticker.get("last")
        if current_price is None:
            ticker = self._fetch_ticker_safe()
            current_price = ticker.get("last") if ticker else None
        if current_price and not _within_band(current_price, self.lower, self.upper):
            return
        if not self.open_tranches:
            next_price = _grid_next_after_start(self.ref, self.step)
        else:
            highest_entry = max(_safe_float(t["buy_px"]) for t in self.open_tranches)
            next_price = max(self.lower, _next_lower_after_buy(highest_entry, self.step))
        if next_price > self.ref or next_price < self.lower:
            return
        self._ensure_pending_at_price(next_price)

    def _ensure_pending_at_price(self, price: float):
        if price > self.ref or self._has_open_order_at("buy", price):
            return
        client_id = f"{GBOT_PREFIX}BUY_{int(price*10)}_{int(time.time())}"
        params = {"client_order_id": client_id}
        if self.is_delta_exchange and self.product_id:
            params.update({"product_id": self.product_id, "order_type": "limit_order"})
        try:
            self._check_rate_limit()
            order = _retry_operation(
                self.ex.create_order, self.symbol_ccxt, "limit", "buy", self.lot, price, params, max_retries=2
            )
            self._track_api_call(ORDER_WEIGHT)
            order_id = order.get("id")
            if order_id:
                self._active_client_ids.add(client_id)
                self.pending_buy = {"px": price, "order_id": order_id, "client_id": client_id}
                log.info(orange(f"GridBot: Placed BUY {self.lot} @{_fmt_px(price)} (id: {order_id})"))
            else:
                log.error("Create order returned no ID")
                self._enter_cooldown()
        except Exception as e:
            log.error(f"Failed to place BUY @{_fmt_px(price)}: {e}")
            self._enter_cooldown()

    def _place_tp_sell(self, price: float) -> Tuple[Optional[str], Optional[str]]:
        client_id = f"{GBOT_PREFIX}TP_{int(price*10)}_{int(time.time())}"
        params = {"client_order_id": client_id, "reduce_only": True}
        if self.is_delta_exchange and self.product_id:
            params.update({"product_id": self.product_id, "order_type": "limit_order"})
        try:
            self._check_rate_limit()
            order = _retry_operation(
                self.ex.create_order, self.symbol_ccxt, "limit", "sell", self.lot, price, params, max_retries=2
            )
            self._track_api_call(ORDER_WEIGHT)
            order_id = order.get("id")
            if order_id:
                self._active_client_ids.add(client_id)
                log.info(orange(f"GridBot: Placed TP SELL {self.lot} @{_fmt_px(price)} (id: {order_id})"))
                return order_id, client_id
            else:
                log.error("TP create order returned no ID")
                return None, None
        except Exception as e:
            log.error(f"Failed to place TP @{_fmt_px(price)}: {e}")
            self._enter_cooldown()
            return None, None

    def _cancel_pending_if_any(self):
        if not self.pending_buy:
            return
        order_id = self.pending_buy.get("order_id")
        client_id = self.pending_buy.get("client_id", "")
        self.pending_buy = None
        if order_id:
            try:
                self._check_rate_limit()
                _retry_operation(self.ex.cancel_order, order_id, self.symbol_ccxt, max_retries=2)
                self._track_api_call(ORDER_WEIGHT)
                log.info(orange(f"GridBot: Canceled pending BUY {order_id}"))
            except Exception as e:
                log.warning(f"Failed to cancel order {order_id}: {e}")
        if client_id:
            self._active_client_ids.discard(client_id)

    def _try_confirm_by_trades(self, pending: Dict[str, Any]) -> Tuple[bool, float, List[str]]:
        try:
            since = (self.last_trades_since - 30000) if self.last_trades_since else (_now_ms() - 300000)
            self._check_rate_limit()
            trades = _retry_operation(self.ex.fetch_my_trades, self.symbol_ccxt, since, max_retries=2)
            self._track_api_call(10)
        except Exception as e:
            log.warning(f"Fetch trades for confirmation failed: {e}")
            return False, _safe_float(pending["px"]), []
        order_id = pending.get("order_id")
        client_id = pending.get("client_id", "")
        total_qty = 0.0
        weighted_price = 0.0
        fill_ids: List[str] = []
        for trade in trades or []:
            try:
                if str(trade.get("side", "")).lower() != "buy":
                    continue
                trade_order_id = self._get_trade_order_id(trade)
                trade_client_id = self._get_trade_client_order_id(trade)
                if not ((order_id and trade_order_id == order_id) or (client_id and trade_client_id == client_id)):
                    continue
                qty = _safe_float(trade.get("amount"))
                price = _safe_float(trade.get("price"))
                if qty > 0 and price > 0:
                    total_qty += qty
                    weighted_price += qty * price
                    fid = trade.get("id")
                    if fid:
                        fill_ids.append(str(fid))
            except Exception as e:
                log.warning(f"Trade parse error {trade.get('id', '?')}: {e}")
        if total_qty >= self.lot * FILL_THRESHOLD:
            avg_price = weighted_price / max(total_qty, 1e-10)
            return True, avg_price, fill_ids
        return False, _safe_float(pending["px"]), []

    def _try_confirm_by_order(self, pending: Dict[str, Any]) -> Tuple[bool, float]:
        if self.is_delta_exchange:
            return False, _safe_float(pending["px"])
        oid = pending.get("order_id")
        if not oid:
            return False, _safe_float(pending["px"])
        try:
            o = _retry_operation(self.ex.fetch_order, oid, self.symbol_ccxt, max_retries=2)
        except Exception as e:
            log.warning(f"Fetch order {oid} failed: {e}")
            return False, _safe_float(pending["px"])
        status = str(o.get("status", "")).lower()
        if status in ("closed", "filled", "completely_filled"):
            avg = _safe_float(o.get("average") or o.get("price") or pending["px"])
            return True, avg
        return False, _safe_float(pending["px"])

    def _has_open_order_at(self, side: str, price: float) -> bool:
        try:
            oo = _retry_operation(self.ex.fetch_open_orders, self.symbol_ccxt, max_retries=2)
        except Exception as e:
            log.warning(f"Open orders failed: {e}")
            return False
        for o in oo or []:
            try:
                s = str(o.get("side", "")).lower()
                px = _safe_float(o.get("price"))
                cid = self._get_client_order_id(o)
                if s == side.lower() and abs(px - price) <= TICK_SIZE and cid and cid.startswith(GBOT_PREFIX):
                    return True
            except Exception as e:
                log.warning(f"Order check err {o.get('id', '?')}: {e}")
        return False

    def _is_reduce_only(self, o: Dict[str, Any]) -> bool:
        try:
            info = o.get("info") or {}
            reduce_only_val = (o.get("reduceOnly") or o.get("reduce_only") or
                               info.get("reduce_only") or info.get("reduceOnly"))
            if isinstance(reduce_only_val, str):
                return reduce_only_val.lower() == "true"
            return bool(reduce_only_val)
        except Exception:
            return False

    def _enter_cooldown(self, sec: int = None):
        if sec is None:
            sec = COOLDOWN_SECONDS
        self.cooldown_until = int(time.time()) + sec
        log.warning(f"grid: cooldown {sec}s until {self.cooldown_until}")

    def _get_client_order_id(self, order: Dict[str, Any]) -> str:
        info = order.get("info") or {}
        return str(order.get("client_order_id") or order.get("clientOrderId") or
                   info.get("client_order_id") or info.get("clientOrderId") or "")

    def _get_trade_order_id(self, trade: Dict[str, Any]) -> Optional[str]:
        info = trade.get("info") or {}
        order_id = (trade.get("order_id") or trade.get("order") or trade.get("orderId") or
                    info.get("order_id") or info.get("orderId"))
        return str(order_id) if order_id else None

    def _get_trade_client_order_id(self, trade: Dict[str, Any]) -> str:
        info = trade.get("info") or {}
        return str(info.get("client_order_id") or info.get("clientOrderId") or
                   trade.get("client_order_id") or trade.get("clientOrderId") or "")

    def _cleanup_on_exit(self):
        """Cancel only this session’s pending BUY on exit. Do not touch TPs or any GBOT_ from previous sessions."""
        # Cancel pending buy placed by this run
        if self.pending_buy and self.pending_buy.get("order_id"):
            try:
                self._check_rate_limit()
                _retry_operation(self.ex.cancel_order, self.pending_buy["order_id"], self.symbol_ccxt, max_retries=2)
                self._track_api_call(ORDER_WEIGHT)
                log.info(orange(f"cleanup: canceled pending BUY {self.pending_buy['order_id']}"))
            except Exception as e:
                log.warning(f"cleanup: failed to cancel pending BUY {self.pending_buy['order_id']}: {e}")

        # DO NOT cancel reduce-only TP orders here.
        # Log summary
        open_ids = [t.get("tp_id") for t in self.open_tranches if t.get("tp_id")]
        log.info("grid: final state — %d open tranches, total exposure: %d lots, %d active ids",
                 len(self.open_tranches), len(self.open_tranches) * self.lot, len(open_ids or []))

# Public entrypoint
def run_grid_strategy(dc, symbol: str, lower: float, upper: float, step: float,
                      ref: float, lot: Union[int, float], max_open: int = 5, hb_sec: int = 10):
    bot = GridBot(dc, sym(symbol), lower, upper, step, ref, lot, max_open, hb_sec)
    bot.run()

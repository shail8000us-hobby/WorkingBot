from __future__ import annotations

import os
import sys


def color(s: str, c: str) -> str:
    codes = {
        "red": "\033[31m",
        "grn": "\033[32m",
        "ylw": "\033[33m",
        "dim": "\033[2m",
        "clr": "\033[0m",
    }
    return f"{codes.get(c, '')}{s}{codes['clr']}"


def preflight(logger=None):
    """Hard stop if EXECUTE_ORDERS=true and user hasn't set I_UNDERSTAND_LIVE=YES."""
    exec_orders = os.getenv("EXECUTE_ORDERS", "false").lower() == "true"
    understood = os.getenv("I_UNDERSTAND_LIVE", "NO").upper() == "YES"
    mode = "LIVE" if exec_orders else "DRY"
    note = f"Mode={mode}  EXECUTE_ORDERS={exec_orders}  I_UNDERSTAND_LIVE={os.getenv('I_UNDERSTAND_LIVE', 'NO')}"
    if exec_orders and not understood:
        msg = f"SAFETY BLOCK: {note} — set I_UNDERSTAND_LIVE=YES to allow live execution."
        if logger:
            logger.error(msg)
        else:
            print(color(msg, "red"), file=sys.stderr)
        sys.exit(2)
    # Optional, log a friendly banner when safe
    ok = f"SAFETY OK: {note}"
    if logger:
        logger.info(ok)
    else:
        print(color(ok, "grn"))

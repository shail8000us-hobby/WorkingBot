#!/usr/bin/env python3
from __future__ import annotations

import os, sys, json, time, threading, logging
from logging.handlers import RotatingFileHandler
from typing import Optional, List, Tuple
from dotenv import load_dotenv

# ---- env
ENV_PATH = os.getenv("ENV_PATH", ".env.live")
if os.path.exists(ENV_PATH): load_dotenv(ENV_PATH)
COLOR_LOGS = os.getenv("COLOR_LOGS","true").lower() in ("1","true","yes")
HEARTBEAT_SEC = int(os.getenv("HEARTBEAT_SEC","5") or "5")
DELTA_SYMBOL = os.getenv("DELTA_SYMBOL","BTC/USD:USD")

# ---- logging
os.makedirs("bot/logs", exist_ok=True)
logging.basicConfig(
  level=getattr(logging, os.getenv("LOG_LEVEL","INFO").upper(), logging.INFO),
  format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
  datefmt="%Y-%m-%d %H:%M:%S",
  handlers=[logging.StreamHandler(sys.stdout), RotatingFileHandler("bot/logs/bot.log", maxBytes=2_000_000, backupCount=3)],
)
log = logging.getLogger("runner")

def _color(txt, code): 
    return f"\x1b[{code}m{txt}\x1b[0m" if COLOR_LOGS else txt
def _arrow(delta):
    if delta>0:  return _color(f"▲ +{delta:g}", "32")
    if delta<0:  return _color(f"▼ {delta:g}", "31")
    return _color("→ 0", "90")
def _field_delta(name, new, old):
    d=new-old
    sym = _color("▲","32") if d>0 else _color("▼","31") if d<0 else _color("→","90")
    return f"{name}={new:g} {sym} {d:+g}"
def _bar_color(old:Tuple[float,float,float,Optional[float],Optional[float]]|None,
               new:Tuple[float,float,float,Optional[float],Optional[float]]):
    if not COLOR_LOGS: return ""
    if old is None: return "36"
    lo0,hi0,_,_,_ = old; lo1,hi1,_,_,_ = new
    if lo1>lo0 and hi1>hi0: return "32"
    if lo1<lo0 and hi1<hi0: return "31"
    return "33"
def _wrap(txt, code): return f"\x1b[{code}m{txt}\x1b[0m" if (COLOR_LOGS and code) else txt

def _load_state()->dict:
    try:
        with open("state.json","r") as f: return json.load(f)
    except Exception: return {}
def _save_state(d:dict)->None:
    try:
        with open("state.json","w") as f: json.dump(d,f,indent=2)
    except Exception: pass

def _grid_levels(lo:float, hi:float, step:float, limit:int=15)->List[float]:
    try:
        if step<=0 or hi<lo: return []
        n=int(round((hi-lo)/step))+1
        lv=[lo+i*step for i in range(max(1,n))]
        return lv[:limit]+(["..."] if len(lv)>limit else [])
    except Exception: return []

def _resolve_product_id(symbol:str)->Optional[int]:
    try:
        from bot.api.delta_client import DeltaClient
        return DeltaClient().resolve_product_id(symbol)
    except Exception: return None

def _parse_env_grid(path:str="grid_config.env")->Optional[Tuple[float,float,float,Optional[float],Optional[float]]]:
    """Parse grid_config.env (LOWER/UPPER/STEP/REFERENCE_LEVEL/LOT)."""
    if not os.path.exists(path): return None
    kv={}
    try:
        with open(path,"r") as f:
            for line in f:
                line=line.strip()
                if not line or line.startswith("#"): continue
                if "=" in line:
                    k,v = line.split("=",1)
                    kv[k.strip()] = v.strip()
        lo = float(kv.get("GRID_LOWER")) if kv.get("GRID_LOWER") else None
        hi = float(kv.get("GRID_UPPER")) if kv.get("GRID_UPPER") else None
        st = float(kv.get("GRID_STEP"))  if kv.get("GRID_STEP")  else None
        rf = float(kv.get("REFERENCE_LEVEL")) if kv.get("REFERENCE_LEVEL") else None
        lt = float(kv.get("LOT")) if kv.get("LOT") else None
        if lo is None or hi is None or st is None: return None
        return (lo,hi,st,rf,lt)
    except Exception:
        return None

def _heartbeat_loop(stop_evt: threading.Event):
    import ccxt
    ex = ccxt.delta({'enableRateLimit': True})
    ex.urls['api']={'public':'https://api.india.delta.exchange','private':'https://api.india.delta.exchange'}
    has_auth=False
    if os.getenv("DELTA_API_KEY") and os.getenv("DELTA_API_SECRET"):
        try:
            ex = ccxt.delta({'apiKey':os.getenv('DELTA_API_KEY'),'secret':os.getenv('DELTA_API_SECRET'),'enableRateLimit':True})
            ex.urls['api']={'public':'https://api.india.delta.exchange','private':'https://api.india.delta.exchange'}
            ex.fetch_balance(); has_auth=True
        except Exception: has_auth=False

    last_prev=None

    # Track applied grid (from state.json) AND staged config (from grid_config.env)
    applied_snap: Optional[Tuple[float,float,float,Optional[float],Optional[float]]] = None
    applied_mark: Optional[int] = None

    staged_snap: Optional[Tuple[float,float,float,Optional[float],Optional[float]]] = None
    staged_mtime: Optional[float] = None

    while not stop_evt.is_set():
        # --- Heartbeat ---
        try:
            t=ex.fetch_ticker(DELTA_SYMBOL); last=t.get("last"); bid=t.get("bid"); ask=t.get("ask")
            spread=(ask-bid) if (ask is not None and bid is not None) else None
            d=(last-last_prev) if (last is not None and last_prev is not None) else 0.0
            hb=f"[HB] last={last} {_arrow(d)}"
            if bid is not None and ask is not None:
                hb+=f"  bid={bid} ask={ask}"
                if spread is not None: hb+=f" spread={spread:g}"
            pos_txt="pos=n/a"; oo_txt="oo=n/a"
            if has_auth:
                try:
                    try: poss=ex.fetch_positions([DELTA_SYMBOL])
                    except Exception: poss=ex.fetch_positions()
                    size=0; entry=None
                    for p in poss or []:
                        if p.get("symbol")==DELTA_SYMBOL and (p.get("contracts") or p.get("size")):
                            size=p.get("contracts") or p.get("size") or 0
                            entry=p.get("entryPrice") or p.get("entry_price"); break
                    pos_txt=f"pos={size}@{entry}" if size else "pos=0"
                except Exception: pos_txt="pos=?"
                try: oos=ex.fetch_open_orders(DELTA_SYMBOL); oo_txt=f"oo={len(oos or [])}"
                except Exception: oo_txt="oo=?"
            hb+=f"  {pos_txt} {oo_txt}"
            log.info(hb)
            if last is not None:
                last_prev=last; s=_load_state(); s["LAST_TICK"]={"ts":int(time.time()),"last":last,"bid":bid,"ask":ask}; _save_state(s)
        except Exception as e:
            log.warning(f"[HB] ticker failed: {e}")

        # --- Detect STAGED changes (grid_config.env edited) ---
        try:
            cfg_path="grid_config.env"
            mt=os.path.getmtime(cfg_path) if os.path.exists(cfg_path) else None
            if mt and (staged_mtime is None or mt>staged_mtime):
                new_staged=_parse_env_grid(cfg_path)
                if new_staged:
                    if staged_snap is None or new_staged!=staged_snap:
                        # Compare to previous staged to show deltas; if none, just print values
                        if staged_snap is None:
                            lo,hi,st,rf,lt=new_staged
                            msg=f"GRID CONFIG CHANGED (pending apply): LOWER={lo:g} UPPER={hi:g} STEP={st:g} REF={rf} LOT={lt}"
                        else:
                            lo0,hi0,st0,rf0,lt0=staged_snap
                            lo1,hi1,st1,rf1,lt1=new_staged
                            parts=[
                                _field_delta("LOWER",lo1,lo0),
                                _field_delta("UPPER",hi1,hi0),
                                _field_delta("STEP", st1,st0),
                                _field_delta("REF",  (rf1 or 0.0),(rf0 or 0.0)) if (rf1 is not None or rf0 is not None) else "REF=None",
                                _field_delta("LOT",  (lt1 or 0.0),(lt0 or 0.0)) if (lt1 is not None or lt0 is not None) else "LOT=None",
                            ]
                            msg="GRID CONFIG CHANGED (pending apply): "+"  ".join(parts)
                        log.info(_wrap(msg,"36"))  # cyan
                    staged_snap=new_staged
                staged_mtime=mt
        except Exception as e:
            log.warning(f"[HB] env-grid watch failed: {e}")

        # --- Detect APPLIED changes (state.json written by set_grid.sh) ---
        try:
            st=_load_state()
            lo=st.get("GRID_LOWER"); hi=st.get("GRID_UPPER"); step=st.get("GRID_STEP")
            ref=st.get("REFERENCE_LEVEL"); lot=st.get("LOT")
            if lo is not None and hi is not None and step is not None:
                new_applied=(float(lo),float(hi),float(step),
                             float(ref) if ref is not None else None,
                             float(lot) if lot is not None else None)
                mark=int(st.get("LAST_SET_AT") or 0)
                should=(applied_snap is None) or (new_applied!=applied_snap) or (mark and mark!=(applied_mark or 0))
                if should:
                    parts=[]
                    if applied_snap is None:
                        lo1,hi1,st1,rf1,lt1=new_applied
                        parts=[f"LOWER={lo1:g}",f"UPPER={hi1:g}",f"STEP={st1:g}",
                               f"REF={rf1}" if rf1 is not None else "REF=None",
                               f"LOT={lt1}" if lt1 is not None else "LOT=None"]
                    else:
                        lo0,hi0,st0,rf0,lt0=applied_snap
                        lo1,hi1,st1,rf1,lt1=new_applied
                        parts=[
                            _field_delta("LOWER",lo1,lo0),
                            _field_delta("UPPER",hi1,hi0),
                            _field_delta("STEP", st1,st0),
                            _field_delta("REF",  (rf1 or 0.0),(rf0 or 0.0)) if (rf1 is not None or rf0 is not None) else "REF=None",
                            _field_delta("LOT",  (lt1 or 0.0),(lt0 or 0.0)) if (lt1 is not None or lt0 is not None) else "LOT=None",
                        ]
                    levels=_grid_levels(new_applied[0], new_applied[1], new_applied[2])
                    bar="GRID UPDATED (applied): "+"  ".join(parts)+f"  levels={levels}"
                    log.info(_wrap(bar, _bar_color(applied_snap, new_applied)))
                    applied_snap=new_applied; applied_mark=mark
        except Exception as e:
            log.warning(f"[HB] state-grid watch failed: {e}")

        stop_evt.wait(HEARTBEAT_SEC)

def main():
    log.info("=== BotPro LIVE MODE START ===")
    log.info(f"EXECUTE_ORDERS={os.getenv('EXECUTE_ORDERS','false')}  I_UNDERSTAND_LIVE={os.getenv('I_UNDERSTAND_LIVE','NO')}  MAX_ACCOUNT_LOSS_INR={os.getenv('MAX_ACCOUNT_LOSS_INR','1500')}")
    pid=_resolve_product_id(DELTA_SYMBOL)
    if pid: log.info(f"Resolved product_id={pid} for symbol={DELTA_SYMBOL}")

    st=_load_state()
    if st.get("GRID_ACTIVE"):
        lo,hi,step=float(st.get("GRID_LOWER")),float(st.get("GRID_UPPER")),float(st.get("GRID_STEP"))
        ref=st.get("REFERENCE_LEVEL"); lot=st.get("LOT")
        levels=_grid_levels(lo,hi,step)
        log.info(f"Active Grid: LOWER={lo}  UPPER={hi}  STEP={step}  REF={ref}  LOT={lot}")
        log.info(f"Grid Levels ({len(levels)}): {levels}")

    stop_evt=threading.Event()
    threading.Thread(target=_heartbeat_loop, args=(stop_evt,), name="heartbeat", daemon=True).start()
    try:
        while True: time.sleep(60)
    except KeyboardInterrupt:
        pass
    finally:
        stop_evt.set()

if __name__=="__main__": main()

# --- Hot Reload Hook ---
from bot.state.reconcile import maybe_hot_reload

# Patch runner loop
_old_step = None
try:
    import bot.runner as runner
    if not hasattr(runner, "_hot_patch"):
        _old_step = runner.step

        def _patched_step(state, *a, **kw):
            state = maybe_hot_reload(state)
            return _old_step(state, *a, **kw)

        runner.step = _patched_step
        runner._hot_patch = True
        print("\033[35m[HOT-RELOAD] runner.step patched for live config reload\033[0m")
except Exception as e:
    print("Hot reload patch failed:", e)

# --- Hot Reload Hook (force immediate apply) ---
from bot.state.reconcile import maybe_hot_reload

_old_step = None
try:
    import bot.runner as runner
    if not hasattr(runner, "_hot_patch_v2"):
        _old_step = runner.step

        def _patched_step(state, *a, **kw):
            # Try to reload config
            new_state = maybe_hot_reload(state)
            if new_state is not state:
                print("\033[36m[HOT-RELOAD] Grid config applied instantly\033[0m")
                state = new_state
            return _old_step(state, *a, **kw)

        runner.step = _patched_step
        runner._hot_patch_v2 = True
        print("\033[35m[HOT-RELOAD] runner.step patched for INSTANT config reload\033[0m")
except Exception as e:
    print("Hot reload patch failed:", e)

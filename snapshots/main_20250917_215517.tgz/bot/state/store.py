from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from bot.utils.logging_setup import get_logger


class StateStore:
    def flush(self) -> None:
        """No-op flush for now (API compatibility)."""
        pass

    """
    Minimal JSON-backed state.
    Shape:
      {
        "last_price": 0.0,
        "reference_level": 109800.0,
        "open_positions": []
      }
    """

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.log = get_logger("state")

    def load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"last_price": 0.0, "reference_level": 109800.0, "open_positions": []}
        try:
            return json.loads(self.path.read_text())
        except Exception as e:
            self.log.error(f"Failed to load state: {e}")
            return {"last_price": 0.0, "reference_level": 109800.0, "open_positions": []}

    def save(self, data: Dict[str, Any]) -> None:
        try:
            self.path.write_text(json.dumps(data, indent=2))
        except Exception as e:
            self.log.error(f"Failed to save state: {e}")

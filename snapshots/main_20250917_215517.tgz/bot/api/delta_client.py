import os
import time
import hmac
import json
import hashlib
import requests
from typing import Any, Dict, Optional

from bot.risk.guards import assert_can_trade, RiskBreach


class DeltaClient:
    """
    Minimal, battle-tested adapter for Delta Exchange.
    - Auth: seconds timestamp; signature over METHOD + ts + path + query + body
    - Sends raw JSON (data=...) to match exactly what was signed
    - Includes 'User-Agent' to avoid random 4xx
    """

    def __init__(self):
        self.base = os.getenv(
            "DELTA_BASE_URL", "https://api.india.delta.exchange").rstrip("/")
        self.key = os.getenv("DELTA_API_KEY", "").strip()
        self.sec = os.getenv("DELTA_API_SECRET", "").strip()

        if not self.key or not self.sec:
            raise RuntimeError("Missing DELTA_API_KEY / DELTA_API_SECRET")

        self.session = requests.Session()
        # If you want, add retries here (urllib3 Retry)

    # ---------- signing / request ----------
    def _auth_headers(self, method: str, path: str, query: str, body: str) -> Dict[str, str]:
        ts = str(int(time.time()))  # seconds
        prehash = method.upper() + ts + path + query + body
        sig = hmac.new(self.sec.encode(), prehash.encode(),
                       hashlib.sha256).hexdigest()
        return {
            "api-key": self.key,
            "timestamp": ts,
            "signature": sig,
            "User-Agent": "python-rest-client",
            "Content-Type": "application/json",
        }

    def _req(
        self,
        method: str,
        path: str,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ):
        body = "" if json_body is None else json.dumps(
            json_body, separators=(",", ":"))
        query = ""
        if params:
            # NOTE: server canonicalizes internally; for signing we join without sorting
            query = "?" + "&".join(f"{k}={v}" for k, v in params.items())

        headers = self._auth_headers(method, path, query, body)
        url = self.base + path

        r = self.session.request(
            method=method.upper(),
            url=url,
            params=params,
            data=(body or None),  # send EXACT body we signed
            headers=headers,
            timeout=15,
        )
        r.raise_for_status()
        return r.json()

    # ---------- products / tickers ----------
    def get_products(self):
        return self._req("GET", "/v2/products")

    def resolve_product_id(self, symbol: str) -> int:
        pid_env = os.getenv("DELTA_PRODUCT_ID", "").strip()
        if pid_env:
            return int(pid_env)
        data = self.get_products()
        for p in data.get("result", []):
            if p.get("symbol") == symbol:
                return int(p["id"])
        raise RuntimeError(f"Product ID not found for {symbol}")

    def get_ticker_by_product_id(self, product_id: int) -> Optional[dict]:
        data = self._req("GET", "/v2/tickers",
                         params={"product_ids": product_id})
        arr = data.get("result") or []
        return arr[0] if arr else None

    # ---------- account snapshot for risk canary ----------
    def account_snapshot_inr(self) -> Dict[str, Any]:
        # conservative defaults; replace with real endpoints if you have them
        return {
            "realized_pnl_inr": "0",
            "balance_inr": "999999999",   # prod can be large; guards still applied
            "open_notional_inr": "0",
            "open_orders_count": 0,
        }

    # ---------- orders ----------
    def place_order(
        self,
        *,
        product_id: int,
        side: str,
        size: int,
        limit_price: float | str,
        order_type: str = "limit_order",   # must be 'limit_order'
        time_in_force: str = "gtc",        # must be lowercase 'gtc'
        post_only: bool | None = None,
        client_order_id: str | None = None,
        **extra,
    ):
        # Guard before we hit the wire
        snap = self.account_snapshot_inr()
        assert_can_trade(
            account_snapshot=snap,
            pending_open_orders=0,
            intended_qty=size,
            intended_price=limit_price,
        )

        payload = {
            "product_id": int(product_id),
            "side": side,
            "size": int(size),
            "limit_price": str(limit_price),   # API prefers string
            "order_type": order_type,
            "time_in_force": time_in_force,
        }
        if post_only is not None:
            payload["post_only"] = bool(post_only)
        if client_order_id:
            payload["client_order_id"] = client_order_id
        payload.update(extra)

        return self._req("POST", "/v2/orders", json_body=payload)

    def get_order(self, order_id: int | str):
        return self._req("GET", f"/v2/orders/{order_id}")

    def cancel_order(self, order_id: int | str):
        # server expects string id in JSON
        return self._req("POST", "/v2/orders/cancel", json_body={"id": str(order_id)})

    def list_orders(self, *, product_id: int | None = None, state: str | None = None):
        params = {}
        if product_id is not None:
            params["product_id"] = int(product_id)
        if state:
            params["state"] = state
        return self._req("GET", "/v2/orders", params=params)

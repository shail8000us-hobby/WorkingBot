import os
import logging
from dotenv import load_dotenv

try:
    import ccxt
except Exception as e:
    raise RuntimeError("ccxt is required. Install with: pip install ccxt python-dotenv requests") from e

log = logging.getLogger("runner")

def ensure_ccxt():
    """
    Initialize and return a CCXT Delta exchange instance with correct base URL and credentials.
    Returns a live, rate-limited client with markets loaded.
    """
    # load env (allow ENV_PATH override from parent)
    env_path = os.getenv("ENV_PATH", ".env")
    load_dotenv(env_path)

    api_key = (os.getenv("DELTA_API_KEY") or "").strip()
    api_secret = (os.getenv("DELTA_API_SECRET") or "").strip()
    base_url = (os.getenv("DELTA_BASE_URL") or "https://api.india.delta.exchange").rstrip("/")

    if not api_key or not api_secret:
        log.warning("CCXT: Missing DELTA_API_KEY or DELTA_API_SECRET — private calls will fail.")

    # Construct exchange
    ex = ccxt.delta({
        "apiKey": api_key,
        "secret": api_secret,
        "enableRateLimit": True,
        # delta is futures-only; setting options is harmless
        "options": {"defaultType": "future"},
    })

    # Force base url for both public/private (India cluster by default)
    ex.urls["api"] = {"public": base_url, "private": base_url}
    log.info("CCXT: Using base URL: %s", base_url)

    # Load markets once
    try:
        ex.load_markets()
        log.info("CCXT: Markets loaded (%d symbols).", len(getattr(ex, "symbols", []) or []))
    except Exception as e:
        log.error("CCXT: load_markets failed: %s", e)
        raise

    return ex

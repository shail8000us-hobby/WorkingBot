#!/usr/bin/env python3
from __future__ import annotations
import os, sys, time, json, threading, logging
from logging.handlers import RotatingFileHandler
from typing import List, Optional
from dotenv import load_dotenv
from colorama import Fore, Style

# ---- env
ENV_PATH = os.getenv("ENV_PATH", ".env.live")
if os.path.exists(ENV_PATH):
    load_dotenv(ENV_PATH)

COLOR_LOGS    = os.getenv("COLOR_LOGS","true").lower() in ("1","true","yes")
HEARTBEAT_SEC = int(os.getenv("HEARTBEAT_SEC","5") or "5")
DELTA_SYMBOL  = os.getenv("DELTA_SYMBOL","BTC/USD:USD")

# ---- logging
os.makedirs("bot/logs", exist_ok=True)
logging.basicConfig(
  level=getattr(logging, os.getenv("LOG_LEVEL","INFO").upper(), logging.INFO),
  format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
  datefmt="%Y-%m-%d %H:%M:%S",
  handlers=[
    logging.StreamHandler(sys.stdout),
    RotatingFileHandler("bot/logs/bot.log", maxBytes=2_000_000, backupCount=3)
  ],
)
log = logging.getLogger("runner")

def _color(txt, code): 
    return f"\x1b[{code}m{txt}\x1b[0m" if COLOR_LOGS else txt
def _arrow(delta):
    if delta>0:  return _color(f"▲ +{delta:g}", "32")
    if delta<0:  return _color(f"▼ {delta:g}", "31")
    return _color("→ 0", "90")

def _load_state()->dict:
    try:
        with open("state.json","r") as f: return json.load(f)
    except Exception: return {}
def _save_state(d:dict)->None:
    try:
        with open("state.json","w") as f: json.dump(d,f,indent=2)
    except Exception: pass

def _grid_levels(lo:float, hi:float, step:float, limit:int=15)->List[float]:
    try:
        if step<=0 or hi<lo: return []
        n=int(round((hi-lo)/step))+1
        lv=[lo+i*step for i in range(max(1,n))]
        return lv[:limit]+(["..."] if len(lv)>limit else [])
    except Exception: return []

def _resolve_product_id(symbol:str)->Optional[int]:
    try:
        from bot.api.delta_client import DeltaClient
        return DeltaClient().resolve_product_id(symbol)
    except Exception:
        return None

def _heartbeat_loop(stop_evt: threading.Event):
    import ccxt
    ex = ccxt.delta({'enableRateLimit': True})
    ex.urls['api']={'public':'https://api.india.delta.exchange','private':'https://api.india.delta.exchange'}
    if os.getenv("DELTA_API_KEY") and os.getenv("DELTA_API_SECRET"):
        ex = ccxt.delta({
            'apiKey': os.getenv('DELTA_API_KEY'),
            'secret': os.getenv('DELTA_API_SECRET'),
            'enableRateLimit': True
        })
        ex.urls['api']={'public':'https://api.india.delta.exchange','private':'https://api.india.delta.exchange'}

    last_prev=None

    # Show current grid once
    st=_load_state()
    if st.get("GRID_ACTIVE"):
        lo,hi,sp = float(st.get("GRID_LOWER")), float(st.get("GRID_UPPER")), float(st.get("GRID_STEP"))
        ref = st.get("REFERENCE_LEVEL"); lot = st.get("LOT")
        levels=_grid_levels(lo,hi,sp)
        log.info(f"Active Grid: LOWER={lo}  UPPER={hi}  STEP={sp}  REF={ref}  LOT={lot}")
        log.info(f"Grid Levels ({len(levels)}): {levels}")

    # Watch state.json for apply events (set_grid.sh writes this)
    state_mtime = os.path.getmtime("state.json") if os.path.exists("state.json") else None

    while not stop_evt.is_set():
        # Heartbeat / ticker
        try:
            t=ex.fetch_ticker(DELTA_SYMBOL)
            last=t.get("last"); bid=t.get("bid"); ask=t.get("ask")
            d=(last-last_prev) if (last is not None and last_prev is not None) else 0.0
            spread=(ask-bid) if (ask is not None and bid is not None) else None
            hb=f"[HB] last={last} {_arrow(d)}  bid={bid} ask={ask}"
            if spread is not None: hb+=f" spread={spread:g}"
            hb+="  pos=0 oo=0"
            log.info(hb)
            if last is not None:
                last_prev=last
                ss=_load_state()
                ss["LAST_TICK"]={"ts":int(time.time()),"last":last,"bid":bid,"ask":ask}
                _save_state(ss)
        except Exception as e:
            log.warning(f"[HB] ticker failed: {e}")

        # Detect grid apply by state.json change
        try:
            if os.path.exists("state.json"):
                mt = os.path.getmtime("state.json")
                if state_mtime is None:
                    state_mtime = mt
                elif mt > state_mtime:
                    state_mtime = mt
                    st=_load_state()
                    if st.get("GRID_ACTIVE"):
                        lo,hi,sp = float(st.get("GRID_LOWER")), float(st.get("GRID_UPPER")), float(st.get("GRID_STEP"))
                        ref = st.get("REFERENCE_LEVEL"); lot = st.get("LOT")
                        levels=_grid_levels(lo,hi,sp)
                        # Cyan & bold “applied” line
                        print(f"{Fore.CYAN}{Style.BRIGHT}GRID UPDATED (applied): LOWER={lo}  UPPER={hi}  STEP={sp}  REF={ref}  LOT={lot}  levels={levels}{Style.RESET_ALL}")
        except Exception as e:
            log.warning(f"[HB] state-watch failed: {e}")

        stop_evt.wait(HEARTBEAT_SEC)

def main():
    log.info("=== BotPro LIVE MODE START ===")
    log.info(f"EXECUTE_ORDERS={os.getenv('EXECUTE_ORDERS','false')}  I_UNDERSTAND_LIVE={os.getenv('I_UNDERSTAND_LIVE','NO')}  MAX_ACCOUNT_LOSS_INR={os.getenv('MAX_ACCOUNT_LOSS_INR','1500')}")
    pid = _resolve_product_id(DELTA_SYMBOL)
    if pid: log.info(f"Resolved product_id={pid} for symbol={DELTA_SYMBOL}")

    stop_evt=threading.Event()
    threading.Thread(target=_heartbeat_loop, args=(stop_evt,), name="heartbeat", daemon=True).start()
    try:
        while True: time.sleep(60)
    except KeyboardInterrupt:
        pass
    finally:
        stop_evt.set()

if __name__=="__main__":
    main()

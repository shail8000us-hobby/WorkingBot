# Sync Pack Summary

- Root: `/Users/shailendrasinghrajawat/Desktop/ssr/bot_pro`
- Captured: `2025-09-07T21:21:40+05:30`
- Total files scanned: **85**
- Total chunk files created: **78**

## File type counts

- `.py`: 35
- `.sh`: 22
- `.txt`: 8
- `<noext>`: 5
- `.md`: 4
- `.json`: 3
- `.cfg`: 1
- `.csv`: 1
- `.example`: 1
- `.ini`: 1
- `.log`: 1
- `.toml`: 1
- `.yaml`: 1
- `.zsh`: 1

## Flat tree (all files)

```
.editorconfig
.env
.env.example
.githooks/pre-commit
.gitignore
.pre-commit-config.yaml
LAST_ERROR.txt
audit/README.md
audit/order_audit.py
audit/order_audit.sh
bot/__init__.py
bot/api/__init__.py
bot/api/_orders_helpers.py
bot/api/_ticker_helpers.py
bot/api/client.py
bot/api/delta_client.py
bot/diagnostics.py
bot/logs/bot.log
bot/logs/trades.csv
bot/orders/__init__.py
bot/orders/fill_watcher.py
bot/orders/manager.py
bot/risk/__init__.py
bot/risk/guards.py
bot/run.py
bot/safety.py
bot/state/__init__.py
bot/state/reconcile.py
bot/state/store.py
bot/state.json
bot/strategy/__init__.py
bot/strategy/grid.py
bot/strategy/levels.py
bot/tools/__init__.py
bot/tools/status.py
bot/tools/status_warn.py
bot/utils/__init__.py
bot/utils/config_check.py
bot/utils/logging_setup.py
bot/utils/watchdog.py
debugging/README.md
debugging/run_all.sh
debugging/tail_live.sh
gridbot_pro.egg-info/PKG-INFO
gridbot_pro.egg-info/SOURCES.txt
gridbot_pro.egg-info/dependency_links.txt
gridbot_pro.egg-info/requires.txt
gridbot_pro.egg-info/top_level.txt
mypy.ini
open_terminals.sh
pyproject.toml
reports/README.md
reports/export_pnl.py
reports/export_pnl.sh
requirements.txt
scripts/TREE.txt
scripts/aliases.sh
scripts/clean_run.sh
scripts/deep_audit.sh
scripts/health.sh
scripts/misc_debug/audit_summary.sh
scripts/misc_debug/list_files.py
scripts/misc_debug/make_sync_pack.py
scripts/misc_debug/requirements-dev.txt
scripts/misc_debug/snapshot.sh
scripts/misc_debug/snapshot_workspace.py
scripts/misc_debug/tail.sh
scripts/misc_debug/upgrade_diag.sh
scripts/misc_debug/upgrade_diagnostics.sh
scripts/misc_debug/upgrade_safety.sh
scripts/misc_debug/watch.sh
scripts/organize_debugging.sh
scripts/preflight.sh
scripts/refactor_layout.sh
scripts/run_checks.sh
scripts/shortcuts.zsh
scripts/smoke.sh
scripts/verify_layout.sh
scripts/workspace_manifest.json
scripts/workspace_manifest.md
setup.cfg
state.json
tests/strategy/test_ladder.py
tests/test_config_parse.py
tests/test_imports.py

```

## Paste Instructions
1. Paste this `SUMMARY.md` here first.
2. Then paste each of the following chunk files, in order:

- `CHUNKS/.pre-commit-config.yaml.md`
- `CHUNKS/LAST_ERROR.txt.md`
- `CHUNKS/audit__README.md.md`
- `CHUNKS/audit__order_audit.py.md`
- `CHUNKS/audit__order_audit.sh.md`
- `CHUNKS/bot____init__.py__part1.md`
- `CHUNKS/bot__api____init__.py__part1.md`
- `CHUNKS/bot__api___orders_helpers.py.md`
- `CHUNKS/bot__api___ticker_helpers.py.md`
- `CHUNKS/bot__api__client.py.md`
- `CHUNKS/bot__api__delta_client.py.md`
- `CHUNKS/bot__diagnostics.py.md`
- `CHUNKS/bot__logs__trades.csv.md`
- `CHUNKS/bot__orders____init__.py__part1.md`
- `CHUNKS/bot__orders__fill_watcher.py.md`
- `CHUNKS/bot__orders__manager.py.md`
- `CHUNKS/bot__risk____init__.py__part1.md`
- `CHUNKS/bot__risk__guards.py.md`
- `CHUNKS/bot__run.py.md`
- `CHUNKS/bot__safety.py.md`
- `CHUNKS/bot__state____init__.py__part1.md`
- `CHUNKS/bot__state__reconcile.py.md`
- `CHUNKS/bot__state__store.py.md`
- `CHUNKS/bot__state.json.md`
- `CHUNKS/bot__strategy____init__.py__part1.md`
- `CHUNKS/bot__strategy__grid.py.md`
- `CHUNKS/bot__strategy__levels.py.md`
- `CHUNKS/bot__tools____init__.py__part1.md`
- `CHUNKS/bot__tools__status.py.md`
- `CHUNKS/bot__tools__status_warn.py.md`
- `CHUNKS/bot__utils____init__.py__part1.md`
- `CHUNKS/bot__utils__config_check.py.md`
- `CHUNKS/bot__utils__logging_setup.py.md`
- `CHUNKS/bot__utils__watchdog.py.md`
- `CHUNKS/debugging__README.md.md`
- `CHUNKS/debugging__run_all.sh.md`
- `CHUNKS/debugging__tail_live.sh.md`
- `CHUNKS/gridbot_pro.egg-info__SOURCES.txt.md`
- `CHUNKS/gridbot_pro.egg-info__dependency_links.txt.md`
- `CHUNKS/gridbot_pro.egg-info__requires.txt.md`
- `CHUNKS/gridbot_pro.egg-info__top_level.txt.md`
- `CHUNKS/mypy.ini.md`
- `CHUNKS/open_terminals.sh.md`
- `CHUNKS/pyproject.toml.md`
- `CHUNKS/reports__README.md.md`
- `CHUNKS/reports__export_pnl.py.md`
- `CHUNKS/reports__export_pnl.sh.md`
- `CHUNKS/requirements.txt.md`
- `CHUNKS/scripts__TREE.txt.md`
- `CHUNKS/scripts__aliases.sh.md`
- `CHUNKS/scripts__clean_run.sh.md`
- `CHUNKS/scripts__deep_audit.sh.md`
- `CHUNKS/scripts__health.sh.md`
- `CHUNKS/scripts__misc_debug__audit_summary.sh.md`
- `CHUNKS/scripts__misc_debug__list_files.py.md`
- `CHUNKS/scripts__misc_debug__make_sync_pack.py.md`
- `CHUNKS/scripts__misc_debug__requirements-dev.txt.md`
- `CHUNKS/scripts__misc_debug__snapshot.sh.md`
- `CHUNKS/scripts__misc_debug__snapshot_workspace.py.md`
- `CHUNKS/scripts__misc_debug__tail.sh.md`
- `CHUNKS/scripts__misc_debug__upgrade_diag.sh.md`
- `CHUNKS/scripts__misc_debug__upgrade_diagnostics.sh.md`
- `CHUNKS/scripts__misc_debug__upgrade_safety.sh.md`
- `CHUNKS/scripts__misc_debug__watch.sh.md`
- `CHUNKS/scripts__organize_debugging.sh.md`
- `CHUNKS/scripts__preflight.sh.md`
- `CHUNKS/scripts__refactor_layout.sh.md`
- `CHUNKS/scripts__run_checks.sh.md`
- `CHUNKS/scripts__shortcuts.zsh.md`
- `CHUNKS/scripts__smoke.sh.md`
- `CHUNKS/scripts__verify_layout.sh.md`
- `CHUNKS/scripts__workspace_manifest.json.md`
- `CHUNKS/scripts__workspace_manifest.md.md`
- `CHUNKS/setup.cfg.md`
- `CHUNKS/state.json.md`
- `CHUNKS/tests__strategy__test_ladder.py__part1.md`
- `CHUNKS/tests__test_config_parse.py.md`
- `CHUNKS/tests__test_imports.py.md`

_If the list is long, paste them across multiple messages._

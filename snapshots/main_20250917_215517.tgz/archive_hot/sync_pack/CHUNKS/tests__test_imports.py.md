## tests/test_imports.py (part 1/1)

```text
def test_import_bot_run():
    import importlib

    importlib.import_module("bot.run")

```

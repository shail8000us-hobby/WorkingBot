## bot/utils/watchdog.py (part 1/1)

```text
from __future__ import annotations

import os
import time
from dataclasses import dataclass


@dataclass
class Watchdog:
    max_api_fail: int = int(os.getenv("WD_MAX_API_FAIL", "3"))
    max_stale_s: int = int(os.getenv("WD_MAX_STALE_S", "30"))
    autosave_every: int = int(os.getenv("WD_AUTOSAVE_EVERY", "10"))
    kill_file: str = os.getenv("WD_KILL_FILE", "bot/panic.on")

    api_fail: int = 0
    last_price: float | None = None
    last_ts: float = 0.0
    tick_count: int = 0

    def note_price(self, price: float) -> None:
        now = time.time()
        if self.last_price is None or price != self.last_price:
            self.last_price, self.last_ts = price, now

    def note_api_fail(self) -> None:
        self.api_fail += 1

    def note_api_ok(self) -> None:
        self.api_fail = 0

    def should_halt(self) -> tuple[bool, str]:
        # kill-switch via file
        if os.path.exists(self.kill_file):
            return True, f"Kill switch file present: {self.kill_file}"
        # api failure breaker
        if self.api_fail >= self.max_api_fail:
            return True, f"API failures >= {self.max_api_fail}"
        # stale price breaker
        if self.last_ts and (time.time() - self.last_ts) > self.max_stale_s:
            return True, f"Price stale > {self.max_stale_s}s"
        return False, ""

    def bump_tick(self) -> bool:
        self.tick_count += 1
        return (self.tick_count % self.autosave_every) == 0

```

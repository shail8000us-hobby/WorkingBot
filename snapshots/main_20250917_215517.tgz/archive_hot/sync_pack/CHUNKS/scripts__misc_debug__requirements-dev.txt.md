## scripts/misc_debug/requirements-dev.txt (part 1/1)

```text
ruff
mypy
pytest
pre-commit

```

## pyproject.toml (part 1/1)

```text
[build-system]
requires = ["setuptools>=61.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "gridbot-pro"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = ["python-dotenv", "requests"]

[tool.setuptools.packages.find]
include = ["bot*"]
exclude = ["tests*", "audit*", "reports*", "debugging*"]

[tool.ruff]
line-length = 200
target-version = "py310"

[tool.ruff.lint]
select = ["E", "F", "I"]
ignore = []

[tool.mypy]
python_version = "3.10"
strict = false
ignore_missing_imports = true

[tool.pytest.ini_options]
testpaths = ["tests"]

```

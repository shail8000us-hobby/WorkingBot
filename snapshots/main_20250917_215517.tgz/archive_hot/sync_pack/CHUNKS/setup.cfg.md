## setup.cfg (part 1/1)

```text
[metadata]
name = gridbot-pro
version = 0.1.0

[options]
packages = find:
python_requires = >=3.10
install_requires =
    python-dotenv
    requests

[options.packages.find]
include = bot*
exclude = tests* audit* reports* debugging*

```

## gridbot_pro.egg-info/requires.txt (part 1/1)

```text
python-dotenv
requests

```

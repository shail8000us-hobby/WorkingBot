## requirements.txt (part 1/1)

```text
python-dotenv==1.0.1
requests==2.32.3

```

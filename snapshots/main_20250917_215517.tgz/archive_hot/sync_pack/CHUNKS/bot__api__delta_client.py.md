## bot/api/delta_client.py (part 1/1)

```text
from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from typing import Any, Dict, List, Optional

import requests

from bot.api._orders_helpers import normalize_open_orders
from bot.api._ticker_helpers import extract_price
from bot.utils.logging_setup import get_logger


class DeltaClient:
    def ticker(self, symbol: str) -> dict:
        """Return a ticker-like payload; dry mode returns a dummy price."""
        if getattr(self, "dry_ticker", True):
            return {"symbol": symbol, "last_price": 0.0}
        try:
            return self._req("GET", f"/ticker/{symbol}").json()
        except Exception:
            return {"symbol": symbol, "last_price": 0.0}

    """
    Minimal Delta-style HTTP client used by our bot.
    - Respects env flags: DELTA_DRY_TICKER, DELTA_DRY_ORDERS, DELTA_READ_PRIVATE
    - Sign headers when API key/secret are present
    - Provides a few convenience methods the bot calls during smoke tests
    """

    def __init__(self) -> None:
        self.base = os.getenv("DELTA_BASE_URL", "https://cdn-ind.testnet.deltaex.org")
        self.api_key = os.getenv("DELTA_API_KEY") or None
        self.api_secret = os.getenv("DELTA_API_SECRET") or None
        self.dry_ticker = os.getenv("DELTA_DRY_TICKER", "true").lower() == "true"
        self.dry_orders = os.getenv("DELTA_DRY_ORDERS", "true").lower() == "true"
        self.read_private = os.getenv("DELTA_READ_PRIVATE", "true").lower() == "true"
        self.log = get_logger("delta")

        self.log.info(
            "Mode: dry_ticker=%s, dry_orders=%s, read_private=%s, base=%s",
            self.dry_ticker,
            self.dry_orders,
            self.read_private,
            self.base,
        )

    # ----- signing / headers -----

    def _sign(self, payload: str) -> Optional[str]:
        if not self.api_secret:
            return None
        digest = hmac.new(
            self.api_secret.encode("utf-8"),
            payload.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        return digest

    def _headers(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, str]:
        ts = str(int(time.time() * 1000))
        body_str = json.dumps(body, separators=(",", ":"), ensure_ascii=False) if body else ""
        payload = f"{ts}{method.upper()}{path}{body_str}"
        sig = self._sign(payload)
        h: Dict[str, str] = {"timestamp": ts, "Content-Type": "application/json"}
        if self.api_key:
            h["api-key"] = self.api_key
        if sig:
            h["signature"] = sig
        return h

    def _req(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> requests.Response:
        url = f"{self.base}{path}"
        headers = self._headers(method, path, body)
        if method.upper() == "GET":
            r = requests.get(url, headers=headers, timeout=10)
        else:
            r = requests.request(method.upper(), url, headers=headers, json=body, timeout=10)
        r.raise_for_status()
        return r

    # ----- public helpers the bot uses -----

    def fetch_price(self, symbol: str) -> Optional[float]:
        if self.dry_ticker:
            # Deterministic placeholder price for smoke tests
            return 111000.0
        try:
            r = self._req("GET", f"/ticker?symbol={symbol}", None)
            return extract_price(r.json())
        except Exception as e:  # noqa: BLE001
            self.log.warning("fetch_price failed: %s", e)
            return None

    def open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        if not self.read_private or not self.api_key or not self.api_secret:
            return []
        if self.dry_orders:
            return []
        try:
            r = self._req("GET", "/orders", None)
            return normalize_open_orders(r.json(), symbol=symbol)
        except Exception as e:  # noqa: BLE001
            self.log.warning("open_orders failed: %s", e)
            return []

    def place_order(self, side: str, symbol: str, price: float, size: float) -> Dict[str, Any]:
        if self.dry_orders:
            oid = f"DRY-{side.upper()}-{int(time.time() * 1000)}"
            self.log.info("SIM ORDER %s %s @%s x%s -> %s", side, symbol, price, size, oid)
            return {"order_id": oid, "status": "accepted", "price": price, "size": size, "symbol": symbol}

        body = {"side": side, "symbol": symbol, "price": price, "size": size, "type": "limit"}
        r = self._req("POST", "/orders", body)
        return r.json()

    # Used by fill_watcher during smoke tests
    def order_status(self, order_id: str) -> Dict[str, Any]:
        if self.dry_orders:
            # Pretend it's filled quickly in dry mode
            return {"status": "filled", "order_id": order_id}
        try:
            r = self._req("GET", f"/orders/{order_id}", None)
            return r.json()
        except Exception as e:  # noqa: BLE001
            self.log.warning("order_status failed: %s", e)
            return {"status": "unknown", "order_id": order_id}

    def cancel_order(self, order_id: str) -> Dict[str, Any]:
        if self.dry_orders:
            return {"status": "cancelled", "order_id": order_id}
        try:
            r = self._req("DELETE", f"/orders/{order_id}", None)
            return r.json()
        except Exception as e:  # noqa: BLE001
            self.log.warning("cancel_order failed: %s", e)
            return {"status": "error", "order_id": order_id, "error": str(e)}

```

## bot/state.json (part 1/1)

```text
{"ref": 123456.0, "open_positions": 0}
```

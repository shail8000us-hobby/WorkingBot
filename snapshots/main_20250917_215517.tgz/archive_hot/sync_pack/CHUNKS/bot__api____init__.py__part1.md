## bot/api/__init__.py (empty file)


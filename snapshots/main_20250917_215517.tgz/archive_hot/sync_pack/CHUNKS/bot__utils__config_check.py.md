## bot/utils/config_check.py (part 1/1)

```text
from __future__ import annotations

from dataclasses import asdict
from typing import Tuple

from bot.strategy.grid import GridConfig
from bot.utils.logging_setup import get_logger

log = get_logger("config")


def sanitize_config(cfg: GridConfig, state: dict, env: dict) -> Tuple[GridConfig, dict, bool]:
    """
    Validate and gently fix obvious misconfigurations.
    Returns (cfg, state, ok).
    """
    ok = True
    # step
    if cfg.grid_step <= 0:
        log.error(f"GRID_STEP must be > 0 (got {cfg.grid_step})")
        ok = False
    # bounds
    if cfg.lower_bound >= cfg.upper_bound:
        log.error(f"LOWER_BOUND must be < UPPER_BOUND (got {cfg.lower_bound} >= {cfg.upper_bound})")
        ok = False
    # reference in bounds -> clamp & warn
    ref = state.get("reference_level", cfg.reference_level)
    if ref < cfg.lower_bound or ref > cfg.upper_bound:
        clamped = min(max(ref, cfg.lower_bound), cfg.upper_bound)
        log.warning(f"reference_level {ref} outside bounds; clamping to {clamped}")
        state["reference_level"] = clamped
    # max open
    try:
        max_open = int(env.get("MAX_OPEN", "5"))
    except Exception:
        max_open = 5
        log.warning("MAX_OPEN not an int; using 5")
    if max_open < 1:
        log.warning(f"MAX_OPEN < 1 (got {max_open}); using 1")
        env["MAX_OPEN"] = "1"

    # exec vs dry-orders
    exec_flag = env.get("EXECUTE_ORDERS", "false").lower() == "true"
    dry_orders = env.get("DELTA_DRY_ORDERS", "true").lower() == "true"
    if exec_flag and dry_orders:
        log.info("EXECUTE_ORDERS=true but DELTA_DRY_ORDERS=true -> orders will still be simulated (no network).")

    # symbol
    if not cfg.symbol:
        log.error("SYMBOL is empty.")
        ok = False

    # emit final view
    log.debug(f"Sanitized config: {asdict(cfg)} / state.ref={state.get('reference_level')}")
    return cfg, state, ok

```

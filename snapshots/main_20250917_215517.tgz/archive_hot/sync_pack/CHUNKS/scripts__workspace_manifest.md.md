## scripts/workspace_manifest.md (part 1/1)

```text
# Workspace Snapshot

- Root: `/Users/shailendrasinghrajawat/Desktop/ssr/bot_pro/scripts`
- Captured at: `2025-09-07T21:00:10+05:30`
- Total files (excluding caches/venv): **20**

## File types

- `.sh`: 17
- `.py`: 1
- `.txt`: 1
- `.zsh`: 1

## Tree (flat)

```
aliases.sh
clean_run.sh
deep_audit.sh
health.sh
misc_debug/audit_summary.sh
misc_debug/requirements-dev.txt
misc_debug/snapshot.sh
misc_debug/snapshot_workspace.py
misc_debug/tail.sh
misc_debug/upgrade_diag.sh
misc_debug/upgrade_diagnostics.sh
misc_debug/upgrade_safety.sh
misc_debug/watch.sh
organize_debugging.sh
preflight.sh
refactor_layout.sh
run_checks.sh
shortcuts.zsh
smoke.sh
verify_layout.sh
```

## Previews (first ~32KB of selected text files)

### aliases.sh

```text
# Source me:  source scripts/aliases.sh
alias grid-fast='bash scripts/misc_debug/run_all.sh'
alias grid-smoke='bash scripts/misc_debug/run_all.sh smoke'
alias grid-tail='bash scripts/misc_debug/tail_live.sh'
alias grid-audit='ls -lh audit | tail -n +1'
alias grid-report='ls -lh reports | tail -n +1'

```

### clean_run.sh

```text
#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/Desktop/SSR/bot_pro"

# clear locals (safe)
python3 - <<'PY'
import json, pathlib
p = pathlib.Path("state.json")
d = json.loads(p.read_text()) if p.exists() else {}
d["open_positions"] = []
p.write_text(json.dumps(d, indent=2))
print("state.json cleared: open_positions=[]")
PY

# activate venv & run
. venv/bin/activate
python -m bot.run

```

### deep_audit.sh

```text
#!/usr/bin/env bash
set -euo pipefail

# ---- colors (portable) ----
RED="$(printf '\033[31m')" ; GRN="$(printf '\033[32m')" ; YEL="$(printf '\033[33m')" ; DIM="$(printf '\033[2m')" ; CLR="$(printf '\033[0m')"

say()  { printf '%s%s%s\n'   "$DIM" "$*" "$CLR"; }
ok()   { printf '%s✔ %s%s\n' "$GRN" "$*" "$CLR"; }
warn() { printf '%s▲ %s%s\n' "$YEL" "$*" "$CLR"; }
err()  { printf '%s✖ %s%s\n' "$RED" "$*" "$CLR"; }

ROOT="$(pwd)"
say "Repo root: $ROOT"

# ---------- 5) Empty/bad dirs ----------
say "Looking for empty or stray directories"
empties="$(find . -type d -empty \
  -not -path "./.git*" -not -path "./venv*" -not -path "./__pycache__*" \
  -not -path "./.githooks*" -not -path "." -print | sed 's|^\./||' || true)"
if [ -n "$empties" ]; then
  # iterate line by line
  echo "$empties" | while IFS= read -r d; do
    [ -n "$d" ] && warn "Empty directory: $d (remove if not needed)"
  done
else
  ok "No empty directories (beyond ignored)"
fi

# ---------- 6) Line endings sanity ----------
say "Checking for CRLF line-endings in code/scripts"
crlf="$(git ls-files | grep -E '\.(py|sh|zsh|md|yml|yaml|toml|cfg|ini)$' \
  | while IFS= read -r f; do file "$f"; done | grep ' CRLF ' | cut -d: -f1 || true)"
if [ -n "$crlf" ]; then
  echo "$crlf" | while IFS= read -r f; do
    [ -n "$f" ] && warn "CRLF detected: $f  (fix: dos2unix \"$f\" or enforce .editorconfig)"
  done
else
  ok "No CRLF issues"
fi

# ---------- 7) Oversized tracked files (>5MB) ----------
say "Checking for large tracked files (>5MB)"
sz() { stat -f %z "$1" 2>/dev/null || stat -c %s "$1" 2>/dev/null || echo 0; }
big="$(git ls-files -s | awk '{print $4}' \
  | while IFS= read -r f; do
      [ -f "$f" ] || continue
      bytes="$(sz "$f")"
      if [ "${bytes:-0}" -gt 5242880 ]; then echo "$f"; fi
    done)"
if [ -n "$big" ]; then
  echo "$big" | while IFS= read -r b; do
    [ -n "$b" ] && warn "Large file tracked: $b (consider git-lfs or move under artifacts/)"
  done
else
  ok "No large tracked files"
fi

# ---------- 8) .gitignore sanity ----------
say "Validating .gitignore essentials"
ensure_ign() { grep -qxF "$1" .gitignore || warn "Missing in .gitignore: $1"; }
[ -f .gitignore ] || : > .gitignore
ensure_ign "bot/logs/"
ensure_ign "bot/state.json"
ensure_ign "bot/.autosave.touch"
ok ".gitignore check done"

# ---------- 9) Final summary ----------
ok "Deep audit: structure looks professional and clean (no blockers found in sections 5–8)."

```

### health.sh

```text
#!/bin/bash
set -e

echo "=== Ruff (lint/format check) ==="
ruff check . --select I,E,F
ruff format --check .

echo
echo "=== Mypy (type check) ==="
mypy bot || true

echo
echo "=== Pytest (unit tests) ==="
PYTHONPATH=. pytest -q || true

echo
echo "=== Deep Audit (structure/dirs/large files) ==="
bash scripts/deep_audit.sh || true

echo
echo "=== All checks completed ==="

```

### misc_debug/audit_summary.sh

```text
#!/usr/bin/env bash
set -euo pipefail
JSONL="bot/audit/orders.jsonl"

# Colors (fallback to plain if not a TTY)
if [[ -t 1 ]]; then RED=$'\033[31m'; GRN=$'\033[32m'; YEL=$'\033[33m'; CYA=$'\033[36m'; DIM=$'\033[2m'; CLR=$'\033[0m'
else RED=""; GRN=""; YEL=""; CYA=""; DIM=""; CLR=""
fi

# Ensure we have fresh audit data (order_audit.sh will also create CSV)
if [[ ! -s "$JSONL" ]]; then
  bash debugging/order_audit.sh once >/dev/null 2>&1 || true
fi
[[ -s "$JSONL" ]] || { echo "${YEL}No audit events found (yet).${CLR}"; exit 0; }

python - <<'PY'
import json, pathlib, sys
p = pathlib.Path("bot/audit/orders.jsonl")
events = []
with p.open("r", encoding="utf-8", errors="replace") as f:
    for line in f:
        line = line.strip()
        if not line: continue
        try:
            events.append(json.loads(line))
        except Exception:
            pass

from collections import Counter, defaultdict
cat = Counter(e.get("category","info") for e in events)
lvl = Counter(e.get("level","INFO") for e in events)
side = Counter(e.get("side") for e in events if e.get("side"))

# Keep only interesting last 5 events
interesting = [e for e in events if e.get("category") in {
    "placed_buy","placed_sell","filled","take_profit","error","warning","breaker"
}]
tail = interesting[-5:]

def n(x): return cat.get(x,0)
def L(x): return lvl.get(x,0)

print("\n=== Order Audit Summary ===")
print(f"Total events: {len(events)} | Interesting: {len(interesting)}")
print("Categories:")
print(f"  placed_buy:  {n('placed_buy'):>4}   placed_sell: {n('placed_sell'):>4}   filled: {n('filled'):>4}   take_profit: {n('take_profit'):>4}")
print(f"  warnings:    {n('warning'):>4}   errors:      {n('error'):>4}   breaker: {n('breaker'):>4}")
print("Sides:")
print(f"  buy: {side.get('buy',0):>4}   sell: {side.get('sell',0):>4}")
print("Log levels:")
print(f"  INFO: {L('INFO'):>4}   WARNING: {L('WARNING'):>4}   ERROR: {L('ERROR'):>4}")

if tail:
    print("\nLast 5 interesting events:")
    for e in tail:
        ts = e.get("ts","")
        catg = e.get("category","")
        s = e.get("side") or "-"
        px = e.get("price") or "-"
        q = e.get("qty") or "-"
        txt = e.get("msg","").strip()
        if len(txt) > 120: txt = txt[:117] + "..."
        print(f"  {ts}  {catg:12} side={s:4} qty={q:6} px={px:10}  | {txt}")
PY

```

### misc_debug/requirements-dev.txt

```text
ruff
mypy
pytest
pre-commit

```

### misc_debug/snapshot.sh

```text
#!/usr/bin/env bash
set -euo pipefail

STAMP=$(date +"%Y%m%d-%H%M%S")
OUT="artifacts/${STAMP}"
mkdir -p "$OUT"

# Save bot logs
mkdir -p "$OUT/logs"
if [[ -d bot/logs ]]; then
  cp -R bot/logs "$OUT/" || true
fi

# Save key repo context
git rev-parse --short HEAD >/dev/null 2>&1 && GIT_HEAD=$(git rev-parse --short HEAD) || GIT_HEAD="(no-git)"
{
  echo "Timestamp: $(date -Is)"
  echo "Git HEAD: $GIT_HEAD"
  echo
  echo "=== ENV (redacted) ==="
  env | sed -E 's/(API|SECRET|KEY|TOKEN|PASS)[^=]*=[^$]*/\1=REDACTED/Ig'
  echo
  echo "=== Python ==="
  command -v python && python --version
  echo
  echo "=== pip freeze (first 200 lines) ==="
  pip freeze | head -n 200 || true
  echo
  echo "=== git status ==="
  git status -sb 2>/dev/null || echo "(no git repo)"
} > "$OUT/context.txt"

# Copy config/state if present
[[ -f bot/state.json        ]] && cp bot/state.json        "$OUT/" || true
[[ -f bot/config.yaml       ]] && cp bot/config.yaml       "$OUT/" || true
[[ -f bot/.env              ]] && sed -E 's/(API|SECRET|KEY|TOKEN|PASS)[^=]*=.*/\1=REDACTED/Ig' bot/.env > "$OUT/.env.redacted" || true

# Tail last part of current log for convenience
[[ -f bot/logs/bot.log      ]] && tail -n 500 bot/logs/bot.log > "$OUT/last500.log" || true

echo "Snapshot saved to: ${OUT}"
echo "Zip it (optional): cd artifacts && tar -czf ${STAMP}.tar.gz ${STAMP}"

```

### misc_debug/snapshot_workspace.py

```text
#!/usr/bin/env python3
"""
Snapshot the current VS Code workspace:
- TREE.txt: directory tree
- workspace_manifest.json: per-file metadata (path, size, mtime, sha256, preview)
- workspace_manifest.md: human-friendly report you can paste back to me
Run it from VS Code: Run & Debug → "Snapshot: Workspace".
"""

from __future__ import annotations
import os
import sys
import json
import hashlib
import pathlib
import datetime
import io
from typing import Iterable, Dict, Any

ROOT = pathlib.Path(__file__).resolve().parents[1]

# Folders/files to ignore (safe defaults)
IGNORE_DIRS = {
    ".git", ".mypy_cache", ".pytest_cache", ".ruff_cache", "__pycache__", "venv",
    ".venv", ".idea", ".vscode", ".DS_Store", "node_modules"
}
IGNORE_FILE_PREFIXES = {".DS_Store"}

# Extensions treated as text for previews
TEXT_EXTS = {
    ".py", ".sh", ".md", ".txt", ".json", ".toml", ".yaml", ".yml",
    ".ini", ".cfg", ".conf", ".csv", ".tsv", ".env", ".gitignore"
}

# Preview limits
MAX_PREVIEW_BYTES = 32_000   # ~32 KB of text preview per file
MAX_FILES_PREVIEW = 500      # cap previews to avoid huge reports


def is_ignored_dir(name: str) -> bool:
    return name in IGNORE_DIRS


def is_text_file(path: pathlib.Path) -> bool:
    if path.suffix.lower() in TEXT_EXTS:
        return True
    # Heuristic for shell scripts without extension
    if path.name.endswith(".zsh") or path.name.endswith(".bash"):
        return True
    return False


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def preview_text(path: pathlib.Path, max_bytes: int = MAX_PREVIEW_BYTES) -> str:
    try:
        raw = path.read_bytes()[:max_bytes]
        # Try utf-8, fall back to latin-1
        try:
            text = raw.decode("utf-8", errors="replace")
        except Exception:
            text = raw.decode("latin-1", errors="replace")
        return text
    except Exception as e:
        return f"<<preview error: {e}>>"


def walk_tree(root: pathlib.Path) -> Iterable[pathlib.Path]:
    for base, dirs, files in os.walk(root):
        # prune ignored directories in-place
        dirs[:] = [d for d in dirs if not is_ignored_dir(d)]
        for f in files:
            if any(f.startswith(pfx) for pfx in IGNORE_FILE_PREFIXES):
                continue
            yield pathlib.Path(base) / f


def make_tree_text(root: pathlib.Path) -> str:
    # Quick, deterministic tree (alphabetical)
    lines = []
    for p in sorted(walk_tree(root)):
        rel = p.relative_to(root)
        lines.append(str(rel))
    return "\n".join(lines) + ("\n" if lines else "")


def summarize_extensions(paths: Iterable[pathlib.Path]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    for p in paths:
        ext = p.suffix.lower() or "<noext>"
        counts[ext] = counts.get(ext, 0) + 1
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))


def main() -> int:
    ts = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
    files = list(walk_tree(ROOT))
    total_files = len(files)
    ext_counts = summarize_extensions(files)

    # Write TREE.txt
    tree_txt = make_tree_text(ROOT)
    (ROOT / "TREE.txt").write_text(tree_txt, encoding="utf-8")

    manifest = {
        "root": str(ROOT),
        "timestamp": ts,
        "total_files": total_files,
        "extension_counts": ext_counts,
        "files": []
    }

    # Build per-file records
    previews_done = 0
    for p in sorted(files):
        try:
            stat = p.stat()
            rec: Dict[str, Any] = {
                "path": str(p.relative_to(ROOT)),
                "size": stat.st_size,
                "mtime": datetime.datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="seconds"),
                "sha256": sha256_file(p)
            }
            if is_text_file(p) and previews_done < MAX_FILES_PREVIEW:
                rec["preview"] = preview_text(p)
                previews_done += 1
            manifest["files"].append(rec)
        except Exception as e:
            manifest["files"].append({
                "path": str(p.relative_to(ROOT)),
                "error": f"{e}"
            })

    # Write JSON
    (ROOT / "workspace_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )

    # Write MD summary
    md = io.StringIO()
    md.write(f"# Workspace Snapshot\n\n")
    md.write(f"- Root: `{ROOT}`\n")
    md.write(f"- Captured at: `{ts}`\n")
    md.write(f"- Total files (excluding caches/venv): **{total_files}**\n\n")
    md.write("## File types\n\n")
    for ext, n in ext_counts.items():
        md.write(f"- `{ext}`: {n}\n")
    md.write("\n## Tree (flat)\n\n")
    md.write("```\n")
    md.write(tree_txt[:100_000])  # keep it readable
    md.write("```\n")

    md.write("\n## Previews (first ~32KB of selected text files)\n\n")
    shown = 0
    for rec in manifest["files"]:
        if "preview" in rec:
            md.write(f"### {rec['path']}\n\n")
            md.write("```text\n")
            md.write(rec["preview"])
            md.write("\n```\n\n")
            shown += 1
            if shown >= 50:  # cap in MD to keep it pasteable
                md.write(
                    "_…truncated; more previews are in `workspace_manifest.json`…_\n")
                break

    (ROOT / "workspace_manifest.md").write_text(md.getvalue(), encoding="utf-8")

    print("✅ Snapshot complete:")
    print(f" - TREE.txt")
    print(f" - workspace_manifest.json")
    print(f" - workspace_manifest.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())

```

### misc_debug/tail.sh

```text
#!/usr/bin/env bash
set -euo pipefail

LOG="bot/logs/bot.log"
if [[ ! -f "$LOG" ]]; then
  echo "Log file not found at $LOG. Start the bot once to create it (e.g., python -m bot.run)." >&2
  exit 1
fi

RED=$'\033[31m'; YEL=$'\033[33m'; GRN=$'\033[32m'; BLU=$'\033[34m'; BLD=$'\033[1m'; DIM=$'\033[2m'; CLR=$'\033[0m'

echo "${BLD}Live tail on ${LOG}${CLR}"
echo "${DIM}Highlights:${CLR} ${RED}ERROR${CLR}, ${YEL}WARNING${CLR}, ${GRN}Loop done${CLR}, kill-switch, ticker-fail"

tail -F "$LOG" 2>/dev/null | while IFS= read -r line; do
  case "$line" in
    *"[ERROR]"*|*"Traceback (most recent call last)"*)
      printf "%s%s%s\n" "$RED" "$line" "$CLR"
      ;;
    *"[WARNING]"*)
      printf "%s%s%s\n" "$YEL" "$line" "$CLR"
      ;;
    *"Loop done."*)
      printf "%s%s%s\n" "$GRN" "$line" "$CLR"
      ;;
    *"CIRCUIT BREAKER: Kill switch"*)
      printf "%s%s%s\n" "$BLU" "$line" "$CLR"
      ;;
    *"Ticker failed on all paths"*)
      printf "%s%s%s\n" "$RED" "$line" "$CLR"
      ;;
    *)
      printf "%s\n" "$line"
      ;;
  esac
done

```

### misc_debug/upgrade_diag.sh

```text
#!/usr/bin/env bash
set -euo pipefail

file="bot/run.py"
backup="bot/run.py.bak.$(date +%s)"
cp -v "$file" "$backup"

python3 - <<'PY'
import re, sys, json
from pathlib import Path

p = Path("bot/run.py")
s = p.read_text(encoding="utf-8", errors="replace")
orig = s

# 1) Ensure imports
def ensure_import(src, mod):
    if re.search(rf'(?m)^\s*import\s+{re.escape(mod)}\b', src): return src
    # Insert after first import line if any, else prepend
    m = re.search(r'(?m)^(?:from\s+\S+\s+import\s+\S+|import\s+\S+).*$', src)
    if m:
        return src[:m.end()] + f"\nimport {mod}" + src[m.end():]
    return f"import {mod}\n{src}"

for mod in ("json","time","os","pathlib","logging"):
    s = ensure_import(s, mod)

# 2) Insert diag helper if missing
if "def _wd_diag_emit(" not in s:
    helper = '''
# ---- diagnostics helper (opt-in via WD_DIAG=1) ----
def _wd_diag_emit(stage, extra=None):
    try:
        if not os.environ.get("WD_DIAG"):
            return
        logger = logging.getLogger("runner")
        payload = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "pid": os.getpid(),
            "stage": stage,
        }
        if isinstance(extra, dict):
            payload["extra"] = extra
        try:
            from pathlib import Path as _Path
            _Path("bot/run_snapshot.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception as _e:
            logger.debug("diag snapshot write failed: %s", _e)
        try:
            logger.info("DIAG: %s", json.dumps(payload, separators=(",",":")))
        except Exception as _e:
            pass
    except Exception as e:
        logging.getLogger("runner").debug("diag emit failed: %s", e)
# ---------------------------------------------------
'''
    # put the helper after all imports (first blank line after imports)
    m = re.search(r'(?s)(^(?:from\s+\S+\s+import.*|import\s+\S+).*\n)(?:\n)?', s)
    if m:
        s = s[:m.end()] + helper + s[m.end():]
    else:
        s = helper + s

# 3) Emit "start" before the first Tick log
if "DIAG: " not in s or "stage\":\"start\"" not in s:
    # find first Tick log line
    m = re.search(r'(?m)^([ \t]*)logger\.(?:info|debug)\(\s*[f]?[\'"]Tick\b', s)
    if m:
        indent = m.group(1)
        inject = f"{indent}_wd_diag_emit('start')\n"
        s = s[:m.start()] + inject + s[m.start():]

# 4) Emit "end" right before the "Loop done." banner
loop_pat = r'(?m)^(?P<ind>[ \t]*)logger\.(?:info|debug)\(\s*[\'"]Loop done\.'
if re.search(loop_pat, s) and "stage\":\"end\"" not in s:
    s = re.sub(loop_pat, r"\g<ind>_wd_diag_emit('end')\n\g<ind>logger.info(\"Loop done.", s, count=1)

if s != orig:
    Path("bot/run.py").write_text(s, encoding="utf-8")
    print("✅ Diagnostics hooks inserted (opt-in with WD_DIAG=1).")
else:
    print("ℹ️ No changes made (hooks already present).")
PY

# sanity compile
python3 -m py_compile $(find bot -name '*.py' -print) >/dev/null
echo "✔ upgrade applied and compiled"

```

### misc_debug/upgrade_diagnostics.sh

```text
#!/usr/bin/env bash
set -euo pipefail

echo "➤ Installing diagnostics fingerprint & snapshot"

# 1) Create bot/diagnostics.py
mkdir -p bot
cat > bot/diagnostics.py <<'PY'
from __future__ import annotations
import os, sys, json, hashlib, time, subprocess, shutil, platform
from pathlib import Path
from typing import Dict, Any

SNAPSHOT_PATH = Path("bot/run_snapshot.json")

KEY_ENVS = [
    "EXECUTE_ORDERS","DELTA_DRY_ORDERS","I_UNDERSTAND_LIVE",
    "DELTA_BASE_URL","WD_MAX_API_FAIL","WD_MAX_STALE_S","WD_AUTOSAVE_EVERY",
    "SYMBOL","LOT","STEP","BOUNDS_LOW","BOUNDS_HIGH"
]

def _git_info() -> Dict[str, Any]:
    def run(*cmd):
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
            return out
        except Exception:
            return None
    if shutil.which("git") is None:
        return {"present": False}
    root = run("git","rev-parse","--show-toplevel")
    if not root: return {"present": False}
    branch = run("git","rev-parse","--abbrev-ref","HEAD")
    commit = run("git","rev-parse","HEAD")
    status = run("git","status","--porcelain")
    dirty = bool(status)
    return {"present": True, "root": root, "branch": branch, "commit": commit, "dirty": dirty}

def _env_subset() -> Dict[str, str]:
    out: Dict[str,str] = {}
    for k in KEY_ENVS:
        v = os.getenv(k)
        if v is not None:
            out[k] = v
    return out

def _runtime_info() -> Dict[str, Any]:
    return {
        "python": sys.version.split()[0],
        "executable": sys.executable,
        "platform": platform.platform(),
        "venv": os.getenv("VIRTUAL_ENV"),
        "cwd": str(Path.cwd()),
    }

def _hash_of(obj: Any) -> str:
    b = json.dumps(obj, sort_keys=True, separators=(",",":")).encode()
    return hashlib.sha256(b).hexdigest()

def snapshot(logger=None) -> str:
    """Write a run snapshot JSON and return a short fingerprint string."""
    data = {
        "ts": int(time.time()),
        "env": _env_subset(),
        "runtime": _runtime_info(),
        "git": _git_info()
    }
    try:
        SNAPSHOT_PATH.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")
    except Exception as e:
        if logger: logger.warning(f"DIAG: failed to write snapshot: {e}")
    fp = _hash_of(data)[:12]
    if logger:
        logger.info(f"DIAG: fingerprint={fp} envs={data['env']}")
        gi = data["git"]
        if gi.get("present"):
            logger.info(f"DIAG: git branch={gi.get('branch')} commit={gi.get('commit')}{' (dirty)' if gi.get('dirty') else ''}")
    else:
        print(f"fingerprint={fp} envs={data['env']}")
    return fp
PY

# 2) Patch bot/run.py to import and call diagnostics.snapshot(logger) after safety.preflight
python3 - <<'PY'
import re
from pathlib import Path

p = Path("bot/run.py")
s = p.read_text(encoding="utf-8", errors="replace")
orig = s

# Ensure import line
if not re.search(r'(?m)^\s*from\s+bot\s+import\s+diagnostics\b', s) and \
   not re.search(r'(?m)^\s*import\s+bot\.diagnostics\b', s):
    s = re.sub(r'(?m)^(\s*(?:from\s+\S+\s+import\s+\S+|import\s+\S+).*\n)+',
               lambda m: m.group(0) + "from bot import diagnostics\n",
               s, count=1) or ("from bot import diagnostics\n" + s)

# Find where we already inserted safety.preflight and add diagnostics call right after it.
m = re.search(r'(?m)^\s*safety\.preflight\(logger\)\s*$', s)
if m:
    insert_at = m.end()
    s = s[:insert_at] + "\n" + "diagnostics.snapshot(logger)\n" + s[insert_at:]
else:
    # fallback: before banner or Ping
    m2 = re.search(r'(?m)logger\.info\(\s*[\'\"]=== Bot Startup Status ===[\'\"]\s*\)', s) \
         or re.search(r'(?m)logger\.info\(\s*[f]?[\'\"]Ping\s*->', s)
    if m2:
        s = s[:m2.start()] + "diagnostics.snapshot(logger)\n" + s[m2.start():]

if s != orig:
    p.write_text(s, encoding="utf-8")
    print("✅ Patched run.py: diagnostics.snapshot(logger) added.")
else:
    print("ℹ️ run.py seems already patched; no change.")
PY

# 3) Compile
python3 -m py_compile $(find bot -name '*.py' -print)
echo "✔ Diagnostics upgrade installed"

```

### misc_debug/upgrade_safety.sh

```text
#!/usr/bin/env bash
set -euo pipefail

echo "➤ Installing live-execution safety guard"

# 1) Create bot/safety.py (idempotent overwrite is fine)
mkdir -p bot
cat > bot/safety.py <<'PY'
from __future__ import annotations
import os, sys

def color(s: str, c: str) -> str:
    codes = {"red":"\033[31m","grn":"\033[32m","ylw":"\033[33m","dim":"\033[2m","clr":"\033[0m"}
    return f"{codes.get(c,'')}{s}{codes['clr']}"

def preflight(logger=None):
    """Hard stop if EXECUTE_ORDERS=true and user hasn't set I_UNDERSTAND_LIVE=YES."""
    exec_orders = (os.getenv("EXECUTE_ORDERS","false").lower() == "true")
    understood   = (os.getenv("I_UNDERSTAND_LIVE","NO").upper() == "YES")
    mode = "LIVE" if exec_orders else "DRY"
    note = f"Mode={mode}  EXECUTE_ORDERS={exec_orders}  I_UNDERSTAND_LIVE={os.getenv('I_UNDERSTAND_LIVE','NO')}"
    if exec_orders and not understood:
        msg = f"SAFETY BLOCK: {note} — set I_UNDERSTAND_LIVE=YES to allow live execution."
        if logger: logger.error(msg)
        else:      print(color(msg,"red"), file=sys.stderr)
        sys.exit(2)
    # Optional, log a friendly banner when safe
    ok = f"SAFETY OK: {note}"
    if logger: logger.info(ok)
    else:      print(color(ok,"grn"))
PY

# 2) Patch bot/run.py to import and call safety.preflight() before status banner
python3 - <<'PY'
import re
from pathlib import Path

p = Path("bot/run.py")
s = p.read_text(encoding="utf-8", errors="replace")

orig = s

# Ensure import
if not re.search(r'(?m)^\s*from\s+bot\s+import\s+safety\b', s) and \
   not re.search(r'(?m)^\s*import\s+bot\.safety\b', s):
    # place after first import block
    s = re.sub(r'(?m)^(\s*(?:from\s+\S+\s+import\s+\S+|import\s+\S+).*\n)+',
               lambda m: m.group(0) + "from bot import safety\n",
               s, count=1) or ("from bot import safety\n" + s)

# Insert safety.preflight(logger) just before the "=== Bot Startup Status ===" banner line (or near first Ping/Tick if banner missing)
insertion_done = False

# Primary anchor: banner
m = re.search(r'(?m)logger\.info\(\s*[\'"]=== Bot Startup Status ===[\'"]\s*\)', s)
if m:
    # insert a line right before
    s = s[:m.start()] + "safety.preflight(logger)\n" + s[m.start():]
    insertion_done = True
else:
    # Fallback: before first 'Ping ->' log
    m2 = re.search(r'(?m)logger\.info\(\s*[f]?[\'"]Ping\s*->', s)
    if m2:
        s = s[:m2.start()] + "safety.preflight(logger)\n" + s[m2.start():]
        insertion_done = True

# If still not inserted, just put near top of main
if not insertion_done:
    # After we get a 'logger =' line, insert once
    m3 = re.search(r'(?m)^\s*logger\s*=\s*.*$', s)
    if m3:
        s = s[:m3.end()] + "\n\nsafety.preflight(logger)\n" + s[m3.end():]
        insertion_done = True

if s != orig:
    Path("bot/run.py").write_text(s, encoding="utf-8")
    print("✅ Patched run.py: safety.preflight(logger) added.")
else:
    print("ℹ️ run.py already contains safety preflight (no change).")
PY

# 3) Quick compile sanity
python3 -m py_compile $(find bot -name '*.py' -print)
echo "✔ Safety upgrade installed"

```

### misc_debug/watch.sh

```text
#!/usr/bin/env bash
# Live, colorized tail of bot/logs/bot.log with useful highlights.
set -euo pipefail

LOG="bot/logs/bot.log"
mkdir -p bot/logs
touch "$LOG"

RED="\033[31m"; GRN="\033[32m"; YEL="\033[33m"; CYA="\033[36m"; MAG="\033[35m"; DIM="\033[2m"; CLR="\033[0m"

echo -e "${DIM}Watching $LOG (Ctrl+C to exit)${CLR}"
echo -e "${DIM}Highlights: errors=red, warnings=yellow, orders=cyan/green, breaker=magenta${CLR}"

# portable tail -F (follows even if log rotates)
tail -F "$LOG" | while IFS= read -r line; do
  low="$(printf '%s' "$line" | tr '[:upper:]' '[:lower:]')"

  if [[ "$low" == *"traceback"* || "$low" == *"error"* || "$low" == *"exception"* ]]; then
    printf "${RED}%s${CLR}\n" "$line"
  elif [[ "$low" == *"[warning]"* || "$low" == *"warn"* ]]; then
    printf "${YEL}%s${CLR}\n" "$line"
  elif [[ "$low" == *"circuit breaker"* || "$low" == *"panic.on"* ]]; then
    printf "${MAG}%s${CLR}\n" "$line"
  elif [[ "$low" == *"placed"*buy* || "$low" == *"submitted"*buy* || "$low" == *"new order"*buy* ]]; then
    printf "${CYA}%s${CLR}\n" "$line"
  elif [[ "$low" == *"placed"*sell* || "$low" == *"submitted"*sell* || "$low" == *"take profit"* || "$low" == *"tp sell"* ]]; then
    printf "${CYA}%s${CLR}\n" "$line"
  elif [[ "$low" == *"filled"* || "$low" == *"executed"* || "$low" == *"matched"* ]]; then
    printf "${GRN}%s${CLR}\n" "$line"
  else
    printf "%s\n" "$line"
  fi
done

```

### organize_debugging.sh

```text
#!/usr/bin/env bash
set -euo pipefail

# Colors
GRN="\033[32m"; YEL="\033[33m"; DIM="\033[2m"; CLR="\033[0m"

echo -e "${DIM}➤ Standardizing layout (debugging ⇢ reports/audit)…${CLR}"
mkdir -p debugging reports audit bot/logs scripts

# Patterns to move OUT of scripts/misc_debug/
shopt -s nullglob
moved_any=0

move_to() {
  local dest="$1"; shift
  for f in "$@"; do
    [[ -e "$f" ]] || continue
    mkdir -p "$dest"
    mv "$f" "$dest"/
    echo -e "   ${GRN}moved:${CLR} $f  →  $dest/"
    moved_any=1
  done
}

# A) Reports (analytics/outputs)
move_to reports \
  scripts/misc_debug/export_pnl.py \
  scripts/misc_debug/pnl*.csv \
  scripts/misc_debug/*.xlsx \
  scripts/misc_debug/*.parquet \
  scripts/misc_debug/*.feather

# B) Audit (journals/raw data)
move_to audit \
  scripts/misc_debug/order_audit.py \
  audit/order_audit.sh \
  scripts/misc_debug/*journal*.csv \
  scripts/misc_debug/fills*.json \
  scripts/misc_debug/orders*.json

# C) Things that should STAY in scripts/misc_debug/ (no move, just informative)
stay_list=(
  "scripts/misc_debug/run_all.sh"
  "scripts/misc_debug/tail_live.sh"
  "scripts/preflight.sh"
)
for f in "${stay_list[@]}"; do
  [[ -e "$f" ]] && echo -e "   ${DIM}keep :${CLR} $f"
done

# D) Readmes to clarify intent
if [[ ! -f scripts/misc_debug/README.md ]]; then
  cat > scripts/misc_debug/README.md <<'MD'
# scripts/misc_debug/
Health checks, smoke tests, live log tails, and preflight diagnostics.
Keep analytics and journals OUT of this folder (see ../reports and ../audit).
MD
  echo -e "   ${GRN}created:${CLR} scripts/misc_debug/README.md"
fi

if [[ ! -f reports/README.md ]]; then
  cat > reports/README.md <<'MD'
# reports/
PnL & analytics (CSV/XLSX/Parquet), charts, summaries generated from audit data.
MD
  echo -e "   ${GRN}created:${CLR} reports/README.md"
fi

if [[ ! -f audit/README.md ]]; then
  cat > audit/README.md <<'MD'
# audit/
Raw, append-only execution evidence: fills, order journals, event streams.
These power the reports/ exporters.
MD
  echo -e "   ${GRN}created:${CLR} audit/README.md"
fi

# E) Update handy aliases
cat > scripts/aliases.sh <<'BASH'
# Source me:  source scripts/aliases.sh
alias grid-fast='bash scripts/misc_debug/run_all.sh'
alias grid-smoke='bash scripts/misc_debug/run_all.sh smoke'
alias grid-tail='bash scripts/misc_debug/tail_live.sh'
alias grid-audit='ls -lh audit | tail -n +1'
alias grid-report='ls -lh reports | tail -n +1'
BASH
echo -e "   ${GRN}updated:${CLR} scripts/aliases.sh"
echo -e "${DIM}   Tip: run  source scripts/aliases.sh  to load aliases in this terminal${CLR}"

# F) Summary
if [[ $moved_any -eq 0 ]]; then
  echo -e "${YEL}   Nothing to move; layout already clean.${CLR}"
fi
echo -e "${GRN}✔ Layout normalized.${CLR}"

```

### preflight.sh

```text
#!/usr/bin/env bash
set -euo pipefail

RED=$'\033[31m'; YEL=$'\033[33m'; GRN=$'\033[32m'; BLD=$'\033[1m'; CLR=$'\033[0m'

fail(){ echo "${RED}✖ $*${CLR}"; exit 1; }
warn(){ echo "${YEL}▲ $*${CLR}"; }
ok(){   echo "${GRN}✔ $*${CLR}"; }

echo "${BLD}Pre-flight checks${CLR}"

# 1) Python env sanity
command -v python >/dev/null || fail "python not found in PATH"
python -c "import sys; assert sys.version_info[:2] >= (3,9)" || fail "Python >=3.9 required"
ok "Python present"

# 2) Import sanity (no runtime, just can it import?)
python - <<'PY' || exit 1
try:
    import bot.run  # noqa
    print("ok")
except Exception as e:
    import traceback; traceback.print_exc(); raise
PY
ok "Import sanity ok"

# 3) Grid params sanity
LOW=${GRID_LOWER:-}
UP=${GRID_UPPER:-}
STEP=${GRID_STEP:-}
LOT=${LOT:-}

[[ -z "${LOW}" || -z "${UP}" || -z "${STEP}" || -z "${LOT}" ]] && \
  warn "GRID_LOWER/GRID_UPPER/GRID_STEP/LOT not fully set (bot will use defaults if coded)"

if [[ -n "${LOW}" && -n "${UP}" ]]; then
  awk -v lo="$LOW" -v up="$UP" 'BEGIN{ if (lo>=up) exit 1 }' || fail "GRID_LOWER must be < GRID_UPPER"
fi
if [[ -n "${STEP}" ]]; then
  awk -v s="$STEP" 'BEGIN{ if (s<=0) exit 1 }' || fail "GRID_STEP must be > 0"
fi
if [[ -n "${LOT}" ]]; then
  awk -v l="$LOT" 'BEGIN{ if (l<=0) exit 1 }' || fail "LOT must be > 0"
fi
ok "Grid params look sensible"

# 4) Safety switches
EXEC=${EXECUTE_ORDERS:-false}
DRY=${DELTA_DRY_ORDERS:-true}
BASE=${DELTA_BASE_URL:-}
ACK=${I_UNDERSTAND_LIVE:-NO}

echo "EXECUTE_ORDERS=$EXEC  DELTA_DRY_ORDERS=$DRY  I_UNDERSTAND_LIVE=$ACK"
if [[ "$EXEC" == "true" && "$DRY" == "false" ]]; then
  [[ "$ACK" == "YES" ]] || fail "Live-like mode detected but I_UNDERSTAND_LIVE!=YES"
  [[ -n "$BASE" ]] || warn "No DELTA_BASE_URL set (bot may default). Confirm testnet/base!"
  ok "Live-like mode explicitly acknowledged"
else
  ok "Not in live-like mode (safe)"
fi

echo
ok "Pre-flight complete"

```

### refactor_layout.sh

```text
#!/usr/bin/env bash
set -euo pipefail

# A) Folders
mkdir -p reports audit debugging scripts
mkdir -p bot/logs

echo "➤ Refactor: ensuring standard layout"
echo "   - reports/: PnL & analytics"
echo "   - audit/:   raw execution journals (future)"
echo "   - scripts/misc_debug/: health checks & tails (already in use)"

# B) Move any report-ish files out of scripts/misc_debug/ if they exist
shopt -s nullglob
found=0
for f in scripts/misc_debug/export_pnl.py scripts/misc_debug/pnl*.csv scripts/misc_debug/*.xlsx scripts/misc_debug/*.parquet scripts/misc_debug/*.feather; do
  mv "$f" reports/ && echo "   moved: $f -> reports/" && found=1 || true
done
[[ $found -eq 0 ]] && echo "   nothing to move from scripts/misc_debug/ (all good)"

# C) Minimal reports/README so the purpose is clear
if [[ ! -f reports/README.md ]]; then
  cat > reports/README.md <<'MD'
# reports/
- **What**: PnL summaries, mark-to-market, analytics exports (CSV/XLSX/Parquet), charts.
- **Sources**: data derived from `audit/` (raw fills/orders) and/or `bot/logs/`.
- **Keep** debugging helpers in `scripts/misc_debug/`, not here.
MD
  echo "   created: reports/README.md"
fi

# D) Optional: create a thin placeholder exporter only if none exists
if [[ ! -f reports/export_pnl.py ]]; then
  cat > reports/export_pnl.py <<'PY'
#!/usr/bin/env python3
"""
Minimal placeholder exporter.
Writes reports/pnl_demo.csv so the shortcut works without touching trading logic.
Replace later with real audit->PnL once fills journaling is enabled.
"""
from pathlib import Path
import csv, time
out = Path("reports/pnl_demo.csv")
out.parent.mkdir(parents=True, exist_ok=True)
with out.open("w", newline="") as fp:
    w = csv.writer(fp)
    w.writerow(["timestamp","ref_price","unrealized_pnl","note"])
    w.writerow([int(time.time()), "", "", "placeholder; replace with real exporter later"])
print(f"✅ wrote {out}")
PY
  chmod +x reports/export_pnl.py
  echo "   created: reports/export_pnl.py (placeholder)"
fi

# E) Shortcuts (aliases) for your daily use
mkdir -p scripts
cat > scripts/aliases.sh <<'BASH'
# Source this file in a shell:  source scripts/aliases.sh
alias grid-smoke='bash scripts/misc_debug/run_all.sh smoke'
alias grid-fast='bash scripts/misc_debug/run_all.sh'
alias grid-tail='bash scripts/misc_debug/tail_live.sh'
alias grid-pnl='python reports/export_pnl.py && ls -l reports/pnl_*.csv reports/pnl_demo.csv 2>/dev/null | tail -n 3'
BASH
echo "   created/updated: scripts/aliases.sh"

echo "➤ Done. Tip: add to your shell profile so aliases persist:"
echo "     source \"$(pwd)/scripts/aliases.sh\""

```

### run_checks.sh

```text
#!/usr/bin/env bash
set -euo pipefail

# ANSI colors
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# safe defaults
export EXECUTE_ORDERS=false DELTA_DRY_ORDERS=true
unset WD_MAX_API_FAIL WD_MAX_STALE_S WD_AUTOSAVE_EVERY DELTA_BASE_URL

# 1) Full smoke (kill-switch, API failover, normal run)
scripts/smoke.sh

# 2) Autosave verification (mtime check for state.json)
export WD_AUTOSAVE_EVERY=2
start_ts=$(date +%s)
scripts/clean_run.sh >/dev/null 2>&1 || true
sleep 3
mtime=$(stat -f %m bot/state.json 2>/dev/null || stat -c %Y bot/state.json 2>/dev/null || echo 0)
echo "state.json mtime=$mtime  start=$start_ts"
[ "$mtime" -ge "$start_ts" ] && echo "Autosave OK ✅" || echo -e "${RED}Autosave check FAILED ❌${NC}"
unset WD_AUTOSAVE_EVERY

# 3) Quick log spot-checks
echo
echo "==== LOG SPOT CHECKS ===="
grep -i "CIRCUIT BREAKER" bot/logs/bot.log | tail -3 || true
grep -i "Ticker failed on all paths" bot/logs/bot.log | tail -3 || true

# 4) Highlight any errors/warnings with color
echo
echo "==== ERRORS / WARNINGS FOUND ===="
grep -iE "ERROR|WARNING|Traceback" bot/logs/bot.log | tail -20 \
  | sed -E "s/(ERROR)/${RED}\1${NC}/Ig; s/(WARNING)/${YELLOW}\1${NC}/Ig; s/(Traceback)/${RED}\1${NC}/Ig" \
  || echo "No errors/warnings in logs 🎉"

echo
echo "All checks done."

```

### shortcuts.zsh

```text
# Shortcuts for Shailendra (zsh-safe functions)
grid-fast()   { bash scripts/misc_debug/run_all.sh "$@"; }
grid-smoke()  { bash scripts/misc_debug/run_all.sh smoke; }
grid-tail()   { bash scripts/misc_debug/tail_live.sh; }
grid-audit()  { ls -lh audit   | tail -n +1; }
grid-report() { ls -lh reports | tail -n +1; }

```

### smoke.sh

```text
#!/usr/bin/env bash
set -euo pipefail

export EXECUTE_ORDERS=false DELTA_DRY_ORDERS=true
unset WD_MAX_API_FAIL WD_MAX_STALE_S WD_AUTOSAVE_EVERY DELTA_BASE_URL

echo "1) Kill-switch…"
python -m bot.run & pid=$!
sleep 1
touch bot/panic.on
wait $pid || true
rm -f bot/panic.on
grep -i "CIRCUIT BREAKER: Kill switch" -n bot/logs/bot.log >/dev/null && echo "   OK"

echo "2) Autosave heartbeat…"
export WD_AUTOSAVE_EVERY=2
scripts/clean_run.sh >/dev/null 2>&1 || true
sleep 3
ls -l bot/state.json bot/.autosave.touch || true
unset WD_AUTOSAVE_EVERY

echo "3) API fail path…"
export WD_MAX_API_FAIL=2 DELTA_BASE_URL="https://invalid.example"
python -m bot.run || true
grep -i "Ticker failed on all paths" -n bot/logs/bot.log >/dev/null && echo "   OK"
unset WD_MAX_API_FAIL DELTA_BASE_URL

echo "4) Normal dry run…"
python -m bot.run
echo "Smoke test done."

```

### verify_layout.sh

```text
#!/usr/bin/env bash
set -euo pipefail

RED=$'\033[31m'; GRN=$'\033[32m'; YEL=$'\033[33m'; DIM=$'\033[2m'; CLR=$'\033[0m'
ok(){ echo "${GRN}✔${CLR} $*"; }
warn(){ echo "${YEL}▲${CLR} $*"; }
err(){ echo "${RED}✖${CLR} $*"; }

fail=0
say(){ echo; echo "${DIM}› $*${CLR}"; }

# 1) Required top-level layout
say "Checking required folders/files"
required=(bot debugging audit reports scripts)
for d in "${required[@]}"; do
  [[ -d "$d" ]] || { err "Missing folder: $d"; fail=1; }
done
[[ -f "bot/run.py" ]] || { err "Missing: bot/run.py"; fail=1; }
[[ -f "debugging/run_all.sh" ]] || { err "Missing: debugging/run_all.sh"; fail=1; }
[[ -f "debugging/tail_live.sh" ]] || { err "Missing: debugging/tail_live.sh"; fail=1; }

# 2) Misplaced or duplicate areas
say "Checking for misplaced folders/files"
if [[ -d bot/audit ]]; then
  err "Found bot/audit (should be top-level audit/). Move it."
  fail=1
fi
# No backups, editor temp, logs, artifacts in tracked tree
bad_globs=( "bot/*.bak*" "*.bak*" "*.tmp" "*~" ".*.swp" ".*.swo" )
for g in "${bad_globs[@]}"; do
  while IFS= read -r -d '' f; do
    err "Remove backup/temp artifact: $f"
    fail=1
  done < <(find . -path './venv' -prune -o -name "$g" -print0 2>/dev/null)
done

# 3) Enforce executability for scripts
say "Checking executable bits on scripts"
need_exec=( debugging/*.sh scripts/*.sh audit/*.sh reports/*.sh )
while IFS= read -r -d '' f; do
  [[ -x "$f" ]] || { err "Script not executable: $f (fix: chmod +x \"$f\")"; fail=1; }
done < <(printf "%s\0" ${need_exec[@]} 2>/dev/null | xargs -0 ls 2>/dev/null | tr '\n' '\0')

# 4) Enforce “code in bot/, tools in audit/reports/scripts, logs & state ignored”
say "Scanning for logs/state under version control"
tracked_problem=0
for f in bot/logs bot/.autosave.touch bot/state.json; do
  [[ -e "$f" ]] || continue
  # If present, they should be git-ignored; warn if tracked
  if git ls-files --error-unmatch "$f" >/dev/null 2>&1; then
    err "File should not be tracked: $f (add to .gitignore)"
    tracked_problem=1
  fi
done
(( tracked_problem == 0 )) && ok "No tracked log/state files"

# 5) Gentle structure lint
say "Structure lint quick pass"
[[ -d bot/api ]]      && ok "bot/api present"
[[ -d bot/strategy ]] && ok "bot/strategy present"
[[ -d bot/utils ]]    && ok "bot/utils present"
[[ -d bot/risk ]]     && ok "bot/risk present"
[[ -d audit ]]        && ok "audit tools present"
[[ -d reports ]]      && ok "reports exporters present"

# 6) Summary
echo
if (( fail == 0 )); then
  ok "Layout validated — looks professional 👍"
  exit 0
else
  err "Layout issues found. Fix the above items."
  exit 1
fi

```


```

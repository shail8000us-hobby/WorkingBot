## tests/strategy/test_ladder.py (empty file)


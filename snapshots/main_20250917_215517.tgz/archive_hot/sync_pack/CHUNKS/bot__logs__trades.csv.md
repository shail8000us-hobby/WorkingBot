## bot/logs/trades.csv (part 1/1)

```text
ts,side,price,qty_lots,action,reason

```

## scripts/TREE.txt (part 1/1)

```text
aliases.sh
clean_run.sh
deep_audit.sh
health.sh
misc_debug/audit_summary.sh
misc_debug/requirements-dev.txt
misc_debug/snapshot.sh
misc_debug/snapshot_workspace.py
misc_debug/tail.sh
misc_debug/upgrade_diag.sh
misc_debug/upgrade_diagnostics.sh
misc_debug/upgrade_safety.sh
misc_debug/watch.sh
organize_debugging.sh
preflight.sh
refactor_layout.sh
run_checks.sh
shortcuts.zsh
smoke.sh
verify_layout.sh

```

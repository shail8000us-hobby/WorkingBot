## bot/run.py (part 1/1)

```text
import json
import logging
import os
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

from bot.api._ticker_helpers import extract_price
from bot.api.delta_client import DeltaClient
from bot.orders.fill_watcher import wait_until_filled_or_timeout
from bot.orders.manager import OrderManager
from bot.risk.guards import RiskGuards
from bot.state.reconcile import reconcile_state
from bot.state.store import StateStore
from bot.strategy.grid import GridConfig, GridStrategy
from bot.strategy.levels import LadderCfg, build_buy_ladder
from bot.utils.config_check import sanitize_config
from bot.utils.logging_setup import get_logger


def banner(log, cfg, state, execute: bool, timeout_s: int, poll_s: float):
    log.info("=== Bot Startup Status ===")
    log.info(f"Env:   testnet={os.getenv('DELTA_TESTNET', 'true')}  base={os.getenv('DELTA_BASE_URL', '')}")
    log.info(f"Mode:  dry_ticker={os.getenv('DELTA_DRY_TICKER', 'true')} dry_orders={os.getenv('DELTA_DRY_ORDERS', 'true')} execute_orders={execute}")
    log.info(f"Strat: symbol={cfg.symbol} step={cfg.grid_step} bounds=({cfg.lower_bound},{cfg.upper_bound}) lot={cfg.lot_size}")
    log.info(f"State: ref={state.get('reference_level')} open_positions={len(state.get('open_positions', []))}")
    log.info(f"Ops:   timeout_s={timeout_s} poll_s={poll_s} log_level={os.getenv('LOG_LEVEL', 'INFO')}")
    log.info("==========================")


def main():
    load_dotenv()
    log = get_logger("runner")

    def _guarded_log(fn):
        def inner(*a, **kw):
            # File-based kill switch
            if os.path.exists("bot/panic.on"):
                try:
                    store.flush()
                    Path("bot/.autosave.touch").touch()
                except Exception:
                    pass
                log.warning("CIRCUIT BREAKER: Kill switch file present: bot/panic.on")
                sys.exit(0)
            return fn(*a, **kw)

        return inner

    log.info = _guarded_log(log.info)
    log.debug = _guarded_log(getattr(log, "debug", log.info))

    cfg = GridConfig(
        symbol=os.getenv("SYMBOL", "BTCUSD"),
        lot_size=float(os.getenv("LOT_SIZE", "1")),
        grid_step=float(os.getenv("GRID_STEP", "500")),
        lower_bound=float(os.getenv("LOWER_BOUND", "108000")),
        upper_bound=float(os.getenv("UPPER_BOUND", "110000")),
        reference_level=float(os.getenv("REFERENCE_LEVEL", "109800")),
    )

    state_path = Path(__file__).resolve().parents[1] / "state.json"
    store = StateStore(state_path)
    state = store.load()
    state.setdefault("reference_level", cfg.reference_level)
    state.setdefault("open_positions", [])

    dc = DeltaClient()
    strat = GridStrategy(cfg)
    risk = RiskGuards(max_open=int(os.getenv("MAX_OPEN", "5")))
    orders = OrderManager(dc)

    execute = os.getenv("EXECUTE_ORDERS", "false").lower() == "true"
    timeout_s = int(os.getenv("ORDER_TIMEOUT_S", "5"))
    poll_s = float(os.getenv("ORDER_POLL_S", "1"))

    state = reconcile_state(dc, state)
    env = dict(os.environ)
    cfg, state, ok = sanitize_config(cfg, state, env)
    if not ok:
        log.error("Startup config invalid. Aborting run.")
        return

    ladder = build_buy_ladder(LadderCfg(cfg.grid_step, cfg.lower_bound, cfg.upper_bound, state["reference_level"]))
    log.info(f"Ladder levels: {ladder[:6]}{'...' if len(ladder) > 6 else ''}")

    banner(log, cfg, state, execute, timeout_s, poll_s)

    for i in range(10):
        px = float(extract_price(dc.ticker(cfg.symbol), cfg.symbol) or 0.0)
        active_levels = {float(p["price"]) for p in state.get("open_positions", []) if "price" in p}
        eligible = [lv for lv in ladder if lv <= px and lv not in active_levels]
        candidate = eligible[-1] if eligible else None

        log.info(f"Tick {i + 1}/10 price={px} ref={state['reference_level']} candidate={candidate}")

        if candidate is not None and risk.can_open(len(state["open_positions"])) and risk.allow_level(active_levels, candidate):
            sell_target = strat.paired_sell_price(candidate)
            if not execute:
                log.info(f"[INTENT] BUY {cfg.symbol} @{candidate} x{cfg.lot_size} -> SELL @{sell_target}")
                state["reference_level"] = candidate
                state["open_positions"].append({"order_id": "demo", "price": candidate, "qty": cfg.lot_size})
                ladder = build_buy_ladder(LadderCfg(cfg.grid_step, cfg.lower_bound, cfg.upper_bound, state["reference_level"]))
            else:
                bid_id = orders.place_buy(cfg.symbol, candidate, cfg.lot_size)
                if bid_id:
                    filled, status = wait_until_filled_or_timeout(dc, bid_id, timeout_s=timeout_s, poll_s=poll_s)
                    if filled:
                        ask_id = orders.place_sell(cfg.symbol, sell_target, cfg.lot_size)
                        state["open_positions"].append(
                            {
                                "order_id": bid_id,
                                "price": candidate,
                                "qty": cfg.lot_size,
                                "paired_sell_id": ask_id,
                                "sell_price": sell_target,
                                "status": "bought",
                            }
                        )
                        state["reference_level"] = candidate
                        ladder = build_buy_ladder(
                            LadderCfg(
                                cfg.grid_step,
                                cfg.lower_bound,
                                cfg.upper_bound,
                                state["reference_level"],
                            )
                        )
                    else:
                        log.warning(f"BUY {bid_id} not filled -> {status}; skipping paired SELL")

        state["last_price"] = px
        store.save(state)
        time.sleep(1)

    log.info("Loop done. (Orders only if EXECUTE_ORDERS=true; orders still DRY unless you disable DELTA_DRY_ORDERS).")


if __name__ == "__main__":
    main()


# ---- diagnostics helper (opt-in via WD_DIAG=1) ----
def _wd_diag_emit(stage, extra=None):
    try:
        if not os.environ.get("WD_DIAG"):
            return
        logger = logging.getLogger("runner")
        payload = {
            "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
            "pid": os.getpid(),
            "stage": stage,
        }
        if isinstance(extra, dict):
            payload["extra"] = extra
        try:
            from pathlib import Path as _Path

            _Path("bot/run_snapshot.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception as _e:
            logger.debug("diag snapshot write failed: %s", _e)
        try:
            logger.info("DIAG: %s", json.dumps(payload, separators=(",", ":")))
        except Exception as _e:
            pass
    except Exception as e:
        logging.getLogger("runner").debug("diag emit failed: %s", e)


# ---------------------------------------------------

```

## bot/risk/guards.py (part 1/1)

```text
from __future__ import annotations

import os


class RiskGuards:
    def __init__(self, max_open: int = 5):
        self.max_open = int(max_open)
        try:
            self.max_total_open_lots = float(os.getenv("MAX_TOTAL_OPEN_LOTS", "10"))
        except Exception:
            self.max_total_open_lots = 10.0

    def can_open(self, open_count: int) -> bool:
        try:
            mo = int(os.getenv("MAX_OPEN", "5"))
        except Exception:
            mo = 5
        return open_count < mo

    def allow_level(self, active_levels, candidate) -> bool:
        return True

    def allow_total_lots(self, current_total_lots: float, add_qty: float) -> bool:
        return (current_total_lots + add_qty) <= float(self.max_total_open_lots)

```

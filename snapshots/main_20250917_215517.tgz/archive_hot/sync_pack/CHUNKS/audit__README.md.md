## audit/README.md (part 1/1)

```text
# audit/
Raw, append-only execution evidence: fills, order journals, event streams.
These power the reports/ exporters.

```

## scripts/health.sh (part 1/1)

```text
#!/bin/bash
set -e

echo "=== Ruff (lint/format check) ==="
ruff check . --select I,E,F
ruff format --check .

echo
echo "=== Mypy (type check) ==="
mypy bot || true

echo
echo "=== Pytest (unit tests) ==="
PYTHONPATH=. pytest -q || true

echo
echo "=== Deep Audit (structure/dirs/large files) ==="
bash scripts/deep_audit.sh || true

echo
echo "=== All checks completed ==="

```

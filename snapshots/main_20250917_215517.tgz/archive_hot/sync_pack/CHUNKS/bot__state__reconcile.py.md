## bot/state/reconcile.py (part 1/1)

```text
from __future__ import annotations

from typing import Any, Dict, List, Set

from bot.api.delta_client import DeltaClient
from bot.utils.logging_setup import get_logger


def reconcile_state(dc: DeltaClient, state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Reconcile local state with the exchange:
      - If DELTA_READ_PRIVATE=false or no keys: shape-only cleanup (what you had).
      - If allowed: fetch open orders and remove any local entries whose order_id is not on exchange.
    """
    log = get_logger("reconcile")
    state.setdefault("open_positions", [])
    cleaned: List[Dict[str, Any]] = []

    # 1) Always prune malformed entries
    for p in state["open_positions"]:
        if all(k in p for k in ("price", "qty")):
            cleaned.append(p)
        else:
            log.warning(f"Pruned malformed position: {p}")
    state["open_positions"] = cleaned

    # 2) If private read permitted, cross-check with exchange
    try:
        remote = dc.open_orders()
        if remote:
            remote_ids: Set[str] = {str(o.get("order_id")) for o in remote if o.get("order_id")}
            before = len(state["open_positions"])
            state["open_positions"] = [p for p in state["open_positions"] if str(p.get("order_id")) in remote_ids or p.get("order_id") == "demo"]
            after = len(state["open_positions"])
            if after != before:
                log.info(f"Reconciled with exchange: positions {before} -> {after} (pruned stale locals)")
            else:
                log.info(f"Reconciled with exchange: positions {after} (no change)")
        else:
            log.info("Reconcile: exchange open-orders unavailable or empty; kept local state as-is.")
    except Exception as e:
        log.warning(f"Reconcile skipped due to error: {e}")

    return state

```

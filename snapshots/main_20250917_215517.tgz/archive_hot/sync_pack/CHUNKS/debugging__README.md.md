## debugging/README.md (part 1/1)

```text
# debugging/
Health checks, smoke tests, live log tails, and preflight diagnostics.
Keep analytics and journals OUT of this folder (see ../reports and ../audit).

```

## open_terminals.sh (part 1/1)

```text
#!/bin/bash

# Path to your project
PROJECT="$HOME/Desktop/SSR/bot_pro"

# Terminal 1: Live log tail
osascript <<EOF
tell application "Terminal"
    do script "cd '$PROJECT'; source venv/bin/activate; bash debugging/tail_live.sh"
    set bounds of front window to {50, 50, 900, 800}
end tell
EOF

# Terminal 2: Bot runner
osascript <<EOF
tell application "Terminal"
    do script "cd '$PROJECT'; source venv/bin/activate"
    set bounds of front window to {950, 50, 1800, 800}
end tell
EOF

```

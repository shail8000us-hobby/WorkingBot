## bot/orders/manager.py (part 1/1)

```text
import os
from typing import Optional

from bot.api.delta_client import DeltaClient
from bot.utils.logging_setup import get_logger

log = get_logger("orders")


def _to_float(x, default):
    try:
        return float(x)
    except Exception:
        return float(default)


class MarketRules:
    def __init__(self):
        self.tick = _to_float(os.getenv("TICK_SIZE", "0.5"), 0.5)
        self.step = _to_float(os.getenv("LOT_STEP", "1"), 1)
        self.max_lots_per_order = float(os.getenv("MAX_LOTS_PER_ORDER", "5"))

    def round_price(self, p: float) -> float:
        t = self.tick
        return int(p / t) * t

    def round_qty(self, q: float) -> float:
        s = self.step
        return int(q / s) * s


class OrderManager:
    def __init__(self, client: DeltaClient):
        self.client = client
        self.rules = MarketRules()

    def _rounded(self, price: float, qty: float):
        rp = self.rules.round_price(price)
        rq = self.rules.round_qty(qty)
        if rp != price or rq != qty:
            log.info(f"orders: rounded price {price}->{rp} qty {qty}->{rq}")
        return rp, rq

    def place_sell(self, symbol: str, price: float, size: float):
        """Wrapper for symmetry with place_buy; delegates to place_order."""
        return self.place_sell(symbol, price, size)

    def place_buy(self, symbol: str, price: float, qty: float) -> Optional[str]:
        rp, rq = self._rounded(price, qty)
        if rq > self.rules.max_lots_per_order:
            log.warning(f"BUY blocked: qty {rq} > MAX_LOTS_PER_ORDER={self.rules.max_lots_per_order}")
            return None
        res = self.client.place_order(side="buy", symbol=symbol, price=rp, size=rq)
        rp, rq = self._rounded(price, qty)
        if rq > self.rules.max_lots_per_order:
            log.warning(f"SELL blocked: qty {rq} > MAX_LOTS_PER_ORDER={self.rules.max_lots_per_order}")
            return None
        res = self.client.place_order(side="sell", symbol=symbol, price=rp, size=rq)
        oid = res.get("order_id") if isinstance(res, dict) else None
        if oid:
            log.info(f"SELL accepted {symbol} @{rp} x{rq} -> {oid}")
            return oid
        log.warning(f"SELL failed response={res}")
        return None

```

## scripts/aliases.sh (part 1/1)

```text
# Source me:  source scripts/aliases.sh
alias grid-fast='bash scripts/misc_debug/run_all.sh'
alias grid-smoke='bash scripts/misc_debug/run_all.sh smoke'
alias grid-tail='bash scripts/misc_debug/tail_live.sh'
alias grid-audit='ls -lh audit | tail -n +1'
alias grid-report='ls -lh reports | tail -n +1'

```

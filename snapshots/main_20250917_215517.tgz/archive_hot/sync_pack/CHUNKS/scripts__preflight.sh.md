## scripts/preflight.sh (part 1/1)

```text
#!/usr/bin/env bash
set -euo pipefail

RED=$'\033[31m'; YEL=$'\033[33m'; GRN=$'\033[32m'; BLD=$'\033[1m'; CLR=$'\033[0m'

fail(){ echo "${RED}✖ $*${CLR}"; exit 1; }
warn(){ echo "${YEL}▲ $*${CLR}"; }
ok(){   echo "${GRN}✔ $*${CLR}"; }

echo "${BLD}Pre-flight checks${CLR}"

# 1) Python env sanity
command -v python >/dev/null || fail "python not found in PATH"
python -c "import sys; assert sys.version_info[:2] >= (3,9)" || fail "Python >=3.9 required"
ok "Python present"

# 2) Import sanity (no runtime, just can it import?)
python - <<'PY' || exit 1
try:
    import bot.run  # noqa
    print("ok")
except Exception as e:
    import traceback; traceback.print_exc(); raise
PY
ok "Import sanity ok"

# 3) Grid params sanity
LOW=${GRID_LOWER:-}
UP=${GRID_UPPER:-}
STEP=${GRID_STEP:-}
LOT=${LOT:-}

[[ -z "${LOW}" || -z "${UP}" || -z "${STEP}" || -z "${LOT}" ]] && \
  warn "GRID_LOWER/GRID_UPPER/GRID_STEP/LOT not fully set (bot will use defaults if coded)"

if [[ -n "${LOW}" && -n "${UP}" ]]; then
  awk -v lo="$LOW" -v up="$UP" 'BEGIN{ if (lo>=up) exit 1 }' || fail "GRID_LOWER must be < GRID_UPPER"
fi
if [[ -n "${STEP}" ]]; then
  awk -v s="$STEP" 'BEGIN{ if (s<=0) exit 1 }' || fail "GRID_STEP must be > 0"
fi
if [[ -n "${LOT}" ]]; then
  awk -v l="$LOT" 'BEGIN{ if (l<=0) exit 1 }' || fail "LOT must be > 0"
fi
ok "Grid params look sensible"

# 4) Safety switches
EXEC=${EXECUTE_ORDERS:-false}
DRY=${DELTA_DRY_ORDERS:-true}
BASE=${DELTA_BASE_URL:-}
ACK=${I_UNDERSTAND_LIVE:-NO}

echo "EXECUTE_ORDERS=$EXEC  DELTA_DRY_ORDERS=$DRY  I_UNDERSTAND_LIVE=$ACK"
if [[ "$EXEC" == "true" && "$DRY" == "false" ]]; then
  [[ "$ACK" == "YES" ]] || fail "Live-like mode detected but I_UNDERSTAND_LIVE!=YES"
  [[ -n "$BASE" ]] || warn "No DELTA_BASE_URL set (bot may default). Confirm testnet/base!"
  ok "Live-like mode explicitly acknowledged"
else
  ok "Not in live-like mode (safe)"
fi

echo
ok "Pre-flight complete"

```

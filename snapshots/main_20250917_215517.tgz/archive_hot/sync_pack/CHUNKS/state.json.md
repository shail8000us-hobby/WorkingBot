## state.json (part 1/1)

```text
{
  "last_price": 0.0,
  "reference_level": 109686.0,
  "open_positions": [
    {
      "order_id": "demo",
      "price": 109690.0,
      "qty": 1.0
    },
    {
      "order_id": "demo",
      "price": 109688.0,
      "qty": 1.0
    },
    {
      "order_id": "demo",
      "price": 109686.0,
      "qty": 1.0
    }
  ]
}
```

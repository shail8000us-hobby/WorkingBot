## bot/__init__.py (empty file)


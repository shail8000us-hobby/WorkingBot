## mypy.ini (part 1/1)

```text
[mypy]
python_version = 3.13
disallow_untyped_defs = False
disallow_incomplete_defs = False
warn_unused_ignores = True
warn_redundant_casts = True
warn_unreachable = True
ignore_missing_imports = True
check_untyped_defs = True
show_error_codes = True
pretty = True

[mypy-tests.*]
ignore_errors = True

```

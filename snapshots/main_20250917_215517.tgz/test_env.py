import os
from dotenv import load_dotenv

# Load variables from .env
load_dotenv()

# Read values
api_key = os.getenv("DELTA_API_KEY")
api_secret = os.getenv("DELTA_API_SECRET")
base_url = os.getenv("DELTA_BASE_URL")
testnet = os.getenv("DELTA_TESTNET")

# Print partial values to confirm
print("DELTA_TESTNET =", testnet)
print("DELTA_BASE_URL =", base_url)
print("DELTA_API_KEY (first 6 chars) =", api_key[:6] + "****")
print("DELTA_API_SECRET (first 6 chars) =", api_secret[:6] + "****")
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f .venv/bin/activate ] && source .venv/bin/activate

python3 - <<'PY'
import os, json
from dotenv import load_dotenv
import ccxt

load_dotenv('.env.live')

# CCXT Delta pointed to India production
ex = ccxt.delta({
    'apiKey': os.getenv('DELTA_API_KEY'),
    'secret': os.getenv('DELTA_API_SECRET'),
    'enableRateLimit': True,
})
ex.urls['api'] = {
    'public':  'https://api.india.delta.exchange',
    'private': 'https://api.india.delta.exchange',
}

symbol = 'BTC/USD:USD'  # Delta perpetual swap

print("=== STATUS (CCXT / LIVE) ===")

# Balances
try:
    bal = ex.fetch_balance()
    total = {k:v for k,v in (bal.get('total') or {}).items() if v}
    free  = {k:v for k,v in (bal.get('free')  or {}).items() if v}
    print("-- Balances --")
    print("Total:", total if total else "(none)")
    print("Free :", free  if free  else "(none)")
except Exception as e:
    print("-- Balances --")
    print("failed:", repr(e))

# Open Orders
try:
    oo = ex.fetch_open_orders(symbol)
    print("-- Open Orders --")
    if oo:
        for o in oo[:8]:
            print(f"{o.get('id')} {o.get('symbol')} {o.get('side')} {o.get('amount')} @ {o.get('price')} [{o.get('status')}]")
    else:
        print("(none)")
except Exception as e:
    print("-- Open Orders --")
    print("failed:", repr(e))

# Positions
def print_pos_list(ps):
    if not ps:
        print("(none)"); return
    for p in ps[:8]:
        sym = p.get('symbol')
        sz  = p.get('contracts') or p.get('size') or p.get('amount')
        ep  = p.get('entryPrice') or p.get('entry_price')
        up  = p.get('unrealizedPnl') or p.get('unrealizedPnlPcnt') or p.get('unrealized_pnl')
        print(f"{sym} size={sz} entry={ep} uPnL={up}")

try:
    # Try unified first
    try:
        ps = ex.fetch_positions([symbol])
    except Exception:
        ps = ex.fetch_positions()  # some versions require no symbol filter
    print("-- Positions --")
    print_pos_list(ps)
except Exception as e:
    # Fallback to raw private endpoint if unified not available
    try:
        raw = ex.private_get_v2_positions_margined()
        print("-- Positions (raw) --")
        rows = raw.get('result') if isinstance(raw, dict) else raw
        if rows:
            for r in rows[:8]:
                sym = r.get('product_symbol')
                sz  = r.get('size')
                ep  = r.get('entry_price')
                up  = r.get('unrealized_pnl')
                print(f"{sym} size={sz} entry={ep} uPnL={up}")
        else:
            print("(none)")
    except Exception as ee:
        print("-- Positions --")
        print("failed:", repr(ee))

print("=== END STATUS ===")
PY

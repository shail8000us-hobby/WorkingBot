#!/usr/bin/env bash
exec bash ../dashboard/preflight.sh "$@"

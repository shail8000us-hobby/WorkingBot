#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

# load secrets
set -a; [ -f .env ] && source .env; set +a

# email target: use EMAIL_TO if set, else fall back to SENDER_EMAIL
EMAIL_TO="${EMAIL_TO:-${SENDER_EMAIL:-}}"

# last hour in ISO (macOS/BSD date flags)
SINCE="$(date -u -v-1H +%Y-%m-%dT%H:%M:%SZ)"
UNTIL="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

# generate + email (no browser open)
.venv/bin/python3 -m bot.reports.pnl_html \
  --since "$SINCE" --until "$UNTIL" \
  --tz Asia/Kolkata --outdir reports \
  ${EMAIL_TO:+--email "$EMAIL_TO"}
